/* Author: Michael Feather

                                Dist 7
    --------------------------------------------------------------
        330B  660Q     660B  1320Q    1320B  2639Q    2639B  5279Q
    --------------  --------------  --------------  --------------
    1            2               2               2               2
    2            9               9               9               9
    3           75              75              75              75
    4          924             924             924             925
    5        11654           11662           11667           11684
    6       146997          147259          147445          147680
    7      1810630         1820015         1825963         1830601
    8     21194046        21539587        21759426        21890847
    9    212630644       226874570       236151189       241449652
   10   1250421451      1695647970      2057787160      2300251615
   NR   1130970896      3262136103      8025972076     17923934990
 Array  2767454208      5534908416     11069816832     22139633664
 Adjust 2617187328      5208178176     10343655936     20489518080
 Actual                                                20437847376


 Adjusted percentages for sizes 660 to 2639    	       Actual 5279
 -------------------------------------------------     -----------
    8       .00809          .00413          .00210          .00107
    9       .08124          .04356          .02283          .01181
   10       .47777          .32557          .19894          .11254
   NR       .43213          .62634          .77593          .87699

 Unadjusted percentages:
    8       .00765          .00389          .00196          .00098
    9       .07683          .04098          .02133          .01090
   10       .45183          .30635          .18589          .10389 

  ----------------------------------------------------------------

  Adjustment and NR calculations:

  Adjusted (from totals.c)     Size
   189322*13824 = 2617187328    660
   376749*13824 = 5208178176   1320
   748239*13824 = 10343655936  2639
  1482170*13824 = 20489518080  5279

  Size   Adjusted     Sum 1-10       NR
  ----  ----------   ----------  -----------
   660  2617187328   1486216432   1130970896
  1320  5208178176   1946042073   3262136103 
  2639  10343655936  2317683860   8025972076
  5279  20489518080  2565583090  17923934990

  ----------------------------------------------------------------

  Dist7   ET bits     Array    
  -----  --------  ----------- 
   660Q      8      2767454208  782*13824*2^8
  1320Q      9      5534908416
  2639Q     10     11069816832
  5279Q     11     22139633664  782*13824*2^11
*/
#include "rc.h"
#include "dist.h"
#include "func.h"

#define SYM_FIRST_MOVE  1     // 0=all first moves, 1=sym first moves
#define USE_CHK_DUP     1 

#define SHOW_DEFINES    FALSE 
#define SHOW_METHODS    FALSE

#define CHECK_RUNTIME 

int depth, quad_depth, seq[20];
long count;
void mget_min_op_e6c();

int main()
{
  char fname[100];
  init();
  snprintf(fname, DAT_FNAME_LEN, "dat/D7_%04.0f%c_%02d%c.dat", 
	  (float)sizeof(dist7)/MEG, get_dist_type(DIST7_TYPE), 
	  D7_GEN_DEPTH, metric);
  printf("Generating: %s\n", fname+4);
  populate_dist_array();
  printf("Writing: %s\n", fname+4);
  make_bin_file(fname, dist7, sizeof(dist7), CHAR); 
  exit(0);
}

void populate_dist_array()
{
  int i;
  struct S_CUBE c;

  c.ep = c.et = 0;
  c.epi = &ep_info[0];
  c.epr[0] = c.epr[1] = c.epr[2] = 0; 

  dist7[0][0][0] = 1;

  for (depth=1; depth <= D7_GEN_DEPTH; depth++)
    {
      cfg_idx = count = 0;
      quad_depth = (depth <= D7_GEN_DEPTH-2) ? 1 : depth-(D7_GEN_DEPTH-3);

      #if SYM_FIRST_MOVE
      search(&c, 1, mvlist1);
      #else
      search(&c, 1, mvlist2);
      #endif

      printf("%2d %10ld\n", depth, count);
      fflush(stdout);
    }

  if (DIST7_TYPE == 1)
    {
      printf("Updating\n");
      fflush(stdout);
      update_quad((unsigned char *)dist7, sizeof(dist7));
    }

  if (DIST7_TYPE == 2)
    {
      dist7[0][0][0] &= 0xF0;
      printf("Updating\n");
      fflush(stdout);
      update_hexd((unsigned char *)dist7, sizeof(dist7));
    }
}

void search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  char eprsym[3];
  int i, ix, mv, rs, tmp, EPRsym;
  struct S_CUBE m;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      m.ep = ep_mov[c->ep][mv];
      m.et = et_mov[c->et][mv];
      m.epr[0] = epr_mov2[epr_mov_idx[c->epi->s0][mv]][c->epr[0]];
      m.epr[1] = epr_mov2[epr_mov_idx[c->epi->s1][mv]][c->epr[1]];
      m.epr[2] = epr_mov2[epr_mov_idx[c->epi->s2][mv]][c->epr[2]];
      m.epi = &ep_info[m.ep];
      if (m.epi->op_ix != -1)
	m.op = ept_min_op[m.epi->op_ix][m.et];
      else
	m.op = m.epi->op;
      m.etsym = get_etsym_m2 (&m);
      if (m.epi->op_ix != -1)
	{
	  m.op_ept = m.op;
	  m.ops_idx = ept_ops_ix2[ept_ops_ix1[m.epi->min]][m.etsym];
	  if (m.ops_idx != -1)
	    {
	      mget_min_op_e6c (&m);
	    }
	}
      EPRsym = epr_sym_m2 (&m);;

      if (n == depth)
	{
	  rs = m.etsym>>(D7_RS);

	  if (DIST7_TYPE == 0)
	    {
	      tmp = 1<<(rs&7);
	      
	      if ((dist7[EPMIN][EPRsym][rs>>3] & tmp) == 0)
		{
	      
		  dist7[EPMIN][EPRsym][rs>>3] |= tmp;
		  count++;
		}
	    }

	  if (DIST7_TYPE == 1)
	    {
	      tmp = (dist7[EPMIN][EPRsym][rs>>2]>>((rs&3)<<1))&3;
	      
	      if (tmp == 0)
		{
		  dist7[EPMIN][EPRsym][rs>>2] |= quad_depth<<((rs&3)<<1);
		  count++;
		}
	    }

	  if (DIST7_TYPE == 2)
	    {
	      tmp = dist7[EPMIN][EPRsym][rs>>1];

	      if (((rs&1)?tmp>>4:tmp&0xF) == 0)
		{
		  dist7[EPMIN][EPRsym][rs>>1] |= ((rs&1)?n<<4:n);
		  count++;
		}
	    }
	}
      else
	{
	  #if USE_CHK_DUP
	  if (n <= 5)
	    if (chk_dup_6c(EPMIN, m.etsym, EPRsym, 0, 0, n))
	      continue;
          #endif

	  seq[n] = mv;
	  search(&m, n+1, seq_gen[mv]);
	}
    }
}

void init()
{
  if (USE_DIST7 == 0)
    {
      printf("Set USE_DIST7 to 1 in dist.h\n");
      exit(0);
    }

  if (SHOW_DEFINES || SHOW_METHODS)
    show_settings();

  init3();
  seq[0] = NIL;
  populate_min_ep();
  populate_epr_min_op();
}

void show()
{
  int i;
  
  for (i=0; i < E_PRMr; i++)
    printf("%5d\n", epr_min_op[i]);
}

void show_defines()
{
  printf("  USE_CHK_DUP      = %d\n", USE_CHK_DUP);
  printf("  SYM_FIRST_MOVE   = %d\n", SYM_FIRST_MOVE);
}

void update_quad(dist, size)
     unsigned char *dist;
     long size;
{
  // assign 0->3, 3->2, 2->1, 1->0
  
  long n;
  unsigned char i, j, k, x;
  unsigned char rearrange[256];
  
  for (i=n=0; n < 256; i++, n++)
    {
      for (j=x=0; j < 4; j++) 
	{
	  k = ((i>>((j&3)<<1))&3);

	  if (k == 0) 
	    x |= 3<<((j&3)<<1);
	  else if (k == 2) 
	    x |= 1<<((j&3)<<1);
	  else if (k == 3) 
	    x |= 2<<((j&3)<<1);
	}  
      rearrange[i] = x;
    }
  
  for (n=0; n < size; n++)
    dist[n] = rearrange[dist[n]];
}

void update_hexd(dist, size)
     unsigned char *dist;
     long size;
{
  long i;

  for (i=0; i < size; i++)
    {
      if ((dist[i]&0xF) == 0)
        dist[i] |= D7_GEN_DEPTH+1;

      if ((dist[i]>>4) == 0)
        dist[i] |= (D7_GEN_DEPTH+1)<<4;
    }

  dist[0] &= 0xF0;
}

void show_settings()
{
  printf("Settings:\n");
  if (SHOW_DEFINES)
    show_defines();
  if (SHOW_METHODS)
    show_methods();
  printf("\n");
}

struct s_infox
{
  short op_ix;                 // ept_op_idx
  unsigned short op  : 6;
  unsigned short min : 10;
  unsigned int s0  : 9;
  unsigned int s1  : 9;
  unsigned int s2  : 9;
};

void mget_min_op_e6c(c)
struct S_CUBE *c;
{	
  char eprsym[3], eprtmp[3];
  int i, n, dif, min_op;
  int oplist[CUBE_SYM];
  long long min, sym;
  struct s_info *epi;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
	c->op = epr_min_op[EPR(c->epr)];
	return;
    }

  for (i=0; i < n; i++)
    oplist[i] = ept_min_ops[c->ops_idx][i+3];

  GET_EPRSYM(eprtmp, c->epi, c->epr, c->op_ept);
  epi = &ep_info[min_ep[c->epi->min]];
  min = EPR(eprtmp);

  for (i=dif=0; i < n; i++)
    {
      GET_EPRSYM(eprsym, epi, eprtmp, oplist[i]);
      sym = EPR(eprsym);

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op_ept][min_op];
}

