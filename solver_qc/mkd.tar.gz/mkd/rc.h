// Author: Michael Feather

#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>

#define P2_GEN_DEPTH         8

#define ET_SYM_METHOD        2
#define CT_SYM_METHOD        2
#define EPR_MOV_METHOD       2
#define EPR_SYM_METHOD       2

#define TRUE                 1
#define FALSE                0
#define MOVES                18

#define USE_EPR_MIN_OP       TRUE
#define USE_GET_MIN_OP_E6C   TRUE
#define USE_CHK_DUP_6C       TRUE

#define ET_MOV_CODE          m.et = et_mov[c->et][mv];
#define CP_MOV_CODE          m.cp = cp_mov[c->cp][mv];
#define CT_MOV_CODE          m.ct = ct_mov[c->ct][mv];
#define CPT_MOV_CODE_L1      m.cpt = cpt_mov[c->cpt.min][op_mv[c->cpt.op][mv]];
#define CPT_MOV_CODE_L2      m.cpt.op = op_op[m.cpt.op][c->cpt.op];
#define CP_SYM_CODE          cpsym = cp_sym[m.cp][m.op];
#define CT_SYM_CODE          ctsym = ct_sym[m.cp][m.ct][m.op];
#define CPT_SYM_CODE         csym = &cpt_sym[m.cpt.min][op_op[m.cpt.op][m.op]];
#define ET_SYM_CODE          m.etsym = GET_ETSYM(&m);
#define EPI_CODE             m.epi = &ep_info[m.ep];
#define OPS_IDX_CODE         m.ops_idx = ept_ops_ix2[ept_ops_ix1[EPMIN]][m.etsym];

// EP_SYM_METHOD
#define USE_EP_MOV           TRUE
#define EPMIN                m.epi->min
#define EP_MIN_OP            m.epi->op
#define EP_MOV_CODE          m.ep = ep_mov[c->ep][mv];

#if (ET_SYM_METHOD == 1)
#define USE_ET_SYM           TRUE
#define USE_ET_SYM_FR        TRUE
#define USE_ET_SYM_UF        TRUE
#define USE_GET_ETSYM_M1     TRUE
#define GET_ETSYM            get_etsym_m1
#endif

#if (ET_SYM_METHOD == 2)
#define USE_ET_SYM           TRUE
#define USE_ET_SYM_FR        TRUE
#define USE_GET_ETSYM_M2     TRUE
#define GET_ETSYM            get_etsym_m2
#endif

// CP6C_SYM_METHOD
#define USE_CP6C_MOV         TRUE
#define USE_CP6C_INFO        TRUE
#define USE_CP6C_SYM         TRUE
#define CP6C_MIN             cpi->min
#define CP6C_MOV_CODE        m.cp6c = cp6c_mov[c->cp6c][mv];

#if (CT_SYM_METHOD == 1)
#define USE_CP_SYM           TRUE
#define USE_CT_SYM           TRUE
#define USE_GET_MIN_OP_3C_M1 TRUE
#define CPSYM                cpsym
#define CTSYM                ctsym
#define GET_MIN_OP_3C        get_min_op_3c_m1
#define CORNER_MOV_CODE      CP_MOV_CODE CT_MOV_CODE
#define CORNER_SYM_CODE      CP_SYM_CODE CT_SYM_CODE
#define CORNER_3C_SOLVED     (m.cp == 0 && m.ct == 0)
#define CT_SYM_DECLARE       int cpsym, ctsym;
#endif

#if (CT_SYM_METHOD == 2)
#define CT_SYM_DECLARE
#define USE_CP_SYM           TRUE
#define USE_CPT_MOV          TRUE
#define USE_CPT_SYM          TRUE
#define USE_GET_MIN_OP_3C_M2 TRUE
#define CPSYM                csym->cp
#define CTSYM                csym->ct
#define GET_MIN_OP_3C        get_min_op_3c_m2
#define CORNER_MOV_CODE      CPT_MOV_CODE_L1 CPT_MOV_CODE_L2
#define CORNER_SYM_CODE      CPT_SYM_CODE
#define CORNER_3C_SOLVED     (m.cpt.min == 0)
#endif

#if (EPR_SYM_METHOD == 1)
#define USE_EPR_SYM_M1       TRUE
#define USE_EPR_SYM2         FALSE
#define USE_GET_EPRSYM_M1    TRUE
#define GET_EPRSYM           get_eprsym_m1
#define EPR_SYM_CODE_NEW     EPRsym = epr_sym_m1(&m);
#else
#define USE_EPR_SYM_M2       TRUE
#define USE_EPR_SYM2         TRUE
#define USE_GET_EPRSYM_M2    TRUE
#define GET_EPRSYM           get_eprsym_m2
#define EPR_SYM_CODE_NEW     EPRsym = epr_sym_m2(&m);
#endif

#if (EPR_MOV_METHOD == 1)
#define USE_EPR_MOV2         FALSE
#define USE_EPR_MOV_M1       TRUE
#define EPR_MOV_CODE_NEW     EPRsym = epr_mov_m1(&m);
#else
#define USE_EPR_MOV2         TRUE
#define USE_EPR_MOV_M2       TRUE
#define EPR_MOV_CODE_NEW     EPRsym = epr_mov_m2(&m);
#endif

#define EPT_OP_IX m.epi->op_ix

// EPT_OP_METHOD
#define USE_EPT_MIN_OP       TRUE
#define GET_MIN_OP_TEST      (m.ops_idx != NIL)

#define OP_CODE \
  if (EPT_OP_IX != NIL) \
    m.op = ept_min_op[EPT_OP_IX][m.et]; \
  else \
    m.op = EP_MIN_OP;

#define EPT_MIN_OP_CODE(get_min_op) \
  if (EPT_OP_IX != NIL) { \
    m.op_ept = m.op; \
    OPS_IDX_CODE \
    if (m.ops_idx != NIL) { \
      get_min_op(&m); \
    } \
  }

#define APPLY_MOVE_3C \
  EP_MOV_CODE \
  ET_MOV_CODE \
  CORNER_MOV_CODE \
  EPI_CODE \
  OP_CODE \
  ET_SYM_CODE \
  EPT_MIN_OP_CODE(GET_MIN_OP_3C) \
  CORNER_SYM_CODE

#define  EP0 c->epi->s0
#define  EP1 c->epi->s1
#define  EP2 c->epi->s2

#define  EP0m m.epi->s0
#define  EP1m m.epi->s1
#define  EP2m m.epi->s2

#if USE_EPR_MOV2
#define EPR_MOV_CODE \
  m.epr[0] = epr_mov2[epr_mov_idx[EP0][mv]][c->epr[0]]; \
  m.epr[1] = epr_mov2[epr_mov_idx[EP1][mv]][c->epr[1]]; \
  m.epr[2] = epr_mov2[epr_mov_idx[EP2][mv]][c->epr[2]];
#else
#define EPR_MOV_CODE \
  m.epr[0] = epr_mov[EP0][c->epr[0]][mv]; \
  m.epr[1] = epr_mov[EP1][c->epr[1]][mv]; \
  m.epr[2] = epr_mov[EP2][c->epr[2]][mv];
#endif

#if USE_EPR_SYM2
#define EPR_SYM_CODE \
  eprsym[slice_map[m.op][0]] = epr_sym2[epr_idx[m.op][EP0m][0]][m.epr[0]]; \
  eprsym[slice_map[m.op][1]] = epr_sym2[epr_idx[m.op][EP1m][1]][m.epr[1]]; \
  eprsym[slice_map[m.op][2]] = epr_sym2[epr_idx[m.op][EP2m][2]][m.epr[2]];
#else
#define EPR_SYM_CODE \
  eprsym[slice_map[m.op][0]] = epr_sym[m.op][EP0m][m.epr[0]][0]; \
  eprsym[slice_map[m.op][1]] = epr_sym[m.op][EP1m][m.epr[1]][1]; \
  eprsym[slice_map[m.op][2]] = epr_sym[m.op][EP2m][m.epr[2]][2];
#endif

#define SHOW_DEPENDENCY_MSGS 0

// 3C = 3 Color cube, 6C = 6 Color cube

#define C_PERM          40320   // 6C corner perms
#define C_PRM           70      // 3C corner perms
#define C_PRMr          576     // 6C/3C corner perms
#define C_PRM_TW        153090  // 3C corners
#define C_TWIST         2187    // corner twist
#define E_PRM           34650   // 3C edge perms
#define E_PRMr          13824   // 6C/3C edge perms
#define E_TWIST         2048    // edge twist (flip)
#define MIN_EP          782     // 3C edge perms reduced by symmetry
#define MIN_CP6C        984     // 6C corner perms  reduced by symmetry
#define MIN_CPT         3393    // 3C corners reduced by symmetry
#define MIN_EP_ET       1601536 // MIN_EP * E_TWIST
#define MIN_EPT         1482170 // 3C edges reduced by symmetry
#define EP_MULTI_MIN_OP 2058    // EPs with multiple symmetry min ops
#define N_EPT_MIN_OP    1290    // #rows in ept_min_op (deduplicated)
#define N_EPT_OPS_IX2   103     // #rows in ept_ops_ix2
#define N_EPT_MIN_OPS   7331    // #rows in ept_min_ops
#define N_EPR_SYM2      176     // #rows in epr_sym2 (uniq)
#define N_POP_LIST      100     // max #rows in pop_list used by populated2
#define N_POP_WIDTH     15      // max length of array name
#define CP6C_OP_ROW     32      // row in cp6c_sym with 48 uniq sym
#define OP_FR           1       // sym op that moves cube Front->Right
#define OP_UF           13      // sym op that moves cube Up->Front
#define OP_UR           21      // sym op that moves cube Up->Right
#define B2_MAX          128     // 2^7
#define B3_MAX          177147  // 3^11
#define SLICE_PRM       495     // 3C slice permutations
#define CUBE_SYM        48      // cube symmetries
#define DAT_FNAME_LEN   21      // dat file name length
#define STACK_DEPTH     30
#define FACELETS        54
#define CHAR            1
#define SHORT           2
#define INT             4
#define NIL             -1
#define MEG             1048576

// max size of cfg lists used by chk_dup_3c & chk_dup_6c

#define CFG_LIST_3C     3400   // 3307
#define CFG_LIST_6C     14000  // 13100

#define EPR(arr) ((arr[0]*24 + arr[1])*24 + arr[2])

#define SEQ_GEN(mv, prev) (((mv&1)||mv==prev) ? seq_gen[mv] : seq_gen2[mv])

#define S_CUBE s_cube2

struct s_cube
{
  char cps[8];
  char cts[8];
  char eps[12];
  char ets[12];
  int cp6c;
  int ct;
  int ep;
  int et;
  char epr[3];
};

struct s_info
{
  short op_ix;                 // ept_op_idx
  unsigned short op  : 6;
  unsigned short min : 10;
  unsigned int s0  : 9;
  unsigned int s1  : 9;
  unsigned int s2  : 9;
};

struct s_min
{	
  short op;
  short min;
};

struct s_cpt
{	
  short cp;
  short ct;
};

struct s_op16
{
  char op1;
  char op2;
};

struct s_epmin
{
  unsigned short op:    6;
  unsigned short min:  10;
};

struct s_cube2
{
  int op;
  int ops_idx;
  int ep;
  int epmin;
  int etsym;
  int et;
  int cp;
  int ct;
  struct s_min cpt;
  struct s_info *epi;
  char epr[3];
  int cp6c;

  #if USE_GET_MIN_OP_E6C
  int op_ept;
  #endif
};

FILE *fp;

char    metric;
char	untwc[3];
char    center_idx[6];
char    pop_list_ix;
char    pop_list[N_POP_LIST][N_POP_WIDTH];
char	b2_cp[B2_MAX],  cp_b2[C_PRM];
char	cnr[8][3],      edg[12][2];
char    cnr2[8][3],     edg2[12][2];
char	cnr_idx[8][3],  edg_idx[12][2];
char	cmv[18][8],     emv[18][12];
char    ccw_mv[18];
char    cp6c_cp3c[C_PERM];
short	cp6c_cpr[C_PERM];
unsigned short b3_ep[B3_MAX];
int	cfg_idx;
int     phase;
int     mvlist1[3], mvlist2[MOVES+1];
int	ep_b3[E_PRM];
void	(*etw[18])(), (*ctw[18])();

#if USE_EP_MOV
unsigned short ep_mov[E_PRM][MOVES];
#endif

#if USE_CPT_MOV
struct s_min cpt_mov[MIN_CPT][MOVES];
#endif

#if USE_CP6C_MOV
unsigned short cp6c_mov[C_PERM][MOVES];
#endif

char    cpt_min_op[C_PRM_TW];
char    epr_min_op[E_PRMr];
char    slice_map[CUBE_SYM][3];
short   ep_slice[E_PRM][3];
short   min_ep[MIN_EP];
short	ept_ops_ix2[N_EPT_OPS_IX2][E_TWIST];
short	cpt_min[C_PRM_TW];
int     b2_slice[4096];
int     slice_ep[SLICE_PRM][3];
int	min_cp6c[MIN_CP6C];
int     ep_min[E_PRM];
int     cp6c_min[C_PERM];

struct  s_op16 op16e[CUBE_SYM];

#if USE_EPT_MIN_OP
char ept_min_op[N_EPT_MIN_OP][E_TWIST];
int  ept_op_idx[E_PRM];
#endif

unsigned short ept_min_ops[N_EPT_MIN_OPS][27];

#if USE_CPT_SYM
struct s_cpt cpt_sym[MIN_CPT][CUBE_SYM];
#endif

#if USE_ET_SYM
short et_sym[E_TWIST][CUBE_SYM];
#endif

#if USE_ET_SYM_FR
short et_sym_FR[SLICE_PRM][E_TWIST];
#endif

#if USE_ET_SYM_UF
short et_sym_UF[SLICE_PRM][E_TWIST];
#endif

#if USE_CP6C_INFO
struct s_min cp6c_info[C_PERM];
#endif

#if USE_CT_SYM
short ct_sym[C_PRM][C_TWIST][CUBE_SYM];
#endif

struct s_info ep_info[E_PRM];

short	ct_mov[C_TWIST][MOVES];
short   et_mov[E_TWIST][MOVES];

char    cp6c_min_op[C_PERM];
char	ep_min_op[E_PRM];

#if USE_EPR_MOV2
char    epr_mov2[24][24];
char    epr_mov_idx[SLICE_PRM][MOVES];
#else
char    epr_mov[SLICE_PRM][24][MOVES];
#endif

#if USE_EPR_SYM2
char    epr_sym2[N_EPR_SYM2][24];
unsigned char epr_idx[CUBE_SYM][SLICE_PRM][3];
#else
char    epr_sym[CUBE_SYM][SLICE_PRM][24][3];
#endif

#if USE_CP_SYM
char cp_sym[C_PRM][CUBE_SYM];
#endif

char    op_op[CUBE_SYM][CUBE_SYM];
char    op_mv[CUBE_SYM][MOVES];
char	inv_op[CUBE_SYM];

char	cp_mov[C_PRM][MOVES];
char    ept_ops_ix1[MIN_EP];
char    ept_op_ix2[MIN_EP];
int     seq_gen[MOVES][MOVES];
int     seq_gen2[MOVES][MOVES];

#if USE_ET_FR
short et_fr[E_TWIST][16];
short et_fr_ix[SLICE_PRM][E_TWIST/16];
#endif
