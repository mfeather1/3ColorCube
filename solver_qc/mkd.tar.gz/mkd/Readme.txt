
  To make dist files for use with the cube solver, first make the
  prerequisite dat files by running the following commands in a linux
  terminal:

  make mkt
  mkt

  If generating Dist3 then set USE_DIST3 to 1 in dist.h (likewise for Dist4),
  also set type, size & depth as desired, then do:

  make mkd
  mkd

  To use these dist files with the solver rename as shown in the chksums
  file.

  --------------------------------------------------------------------------

  DistP2_15F.dat (generated to depth 15) is available at:
  https://drive.google.com/file/d/1SuH1cYFWgALqDsu67zO4S9occZkW49Oz/view?usp=sharing

  To make P2 dist array first generate dists 1 and 2 to depth 9 as described
  above, set desired P2_GEN_DEPTH in rc.h, make and run mkdp2 or mkdp2_sym,
  then make and run mk_distp2_js to convert for use with solver (see
  chksums file for usage).

