/* Author: Michael Feather
   This program makes the phase 2 dist file for the solver.

  Moves    Configs
    1            6
    2           27
    3          120
    4          519
    5         2124
    6         8188
    7        27636
    8        78644
    9       175497
   10       248288
*/

#include "rc.h"
#include "dist.h"
#include "func.h"

int count, depth, seq[STACK_DEPTH];
unsigned char dist[C_PRMr][E_PRMr];

int main()
{
  char fname[DAT_FNAME_LEN];

  init();
  snprintf(fname, DAT_FNAME_LEN, "dat/P2_0004H_%02d%c.dat",
	   P2_GEN_DEPTH, metric);
  printf("Generating: %s\n", fname+4);
  populate_dist_array();
  printf("Writing: %s\n", fname+4);
  make_bin_file(fname, distp2, sizeof(distp2), CHAR);
  exit(0);
}

void populate_dist_array()
{
  int i, j, n;
  struct S_CUBE c;

  c.cp = c.ct = 0;
  c.ep = 0;
  c.et = 0;
  c.epr[0] = 0;
  c.epr[1] = 0;
  c.epr[2] = 0;
  c.cp6c = 0;
  c.cpt.min = 0;
  c.cpt.op = 0;
  c.epi = &ep_info[0];

  printf("  Moves    Configs\n");
  dist[0][0] = 1;

  for (depth=1; depth <= P2_GEN_DEPTH; depth++)
    {
      count = 0;
      search(&c, 1, mvlist2);
      show_dist_count_line(depth, count);
    }

  n = P2_GEN_DEPTH+1;

  for (i=count=0; i < C_PRMr; i++)
    for (j=0; j < E_PRMr; j++)
      if (dist[i][j] == 0)
	{
	  dist[i][j] = n;
	  count++;
	}

  show_dist_count_line(n, count);

  dist[0][0] = 0;

  for (i=0; i < C_PRMr; i++)
    for (j=0; j < E_PRMr; j+=2)
      distp2[i][j/2] = (dist[i][j+1]<<4) + dist[i][j];
}

void search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  int i, mv, tmp, cpsym, ctsym;
  struct s_cpt *csym;
  int dst, cpr, epr;
  struct S_CUBE m;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      EP_MOV_CODE;
      ET_MOV_CODE;
      CORNER_MOV_CODE

      if (n == depth)
	{
	  if (m.ep == 0 && m.et == 0 && CORNER_3C_SOLVED)
	    {
	      seq[n] = mv;
	      CP6C_MOV_CODE;
	      cpr = cp6c_cpr[m.cp6c];
              EPR_MOV_CODE
              epr = EPR(m.epr);

	      if (dist[cpr][epr] == 0)
		{
		  dist[cpr][epr] = depth;
		  count++;
		}
	    }
	}
      else
	{
	  if (n > (depth>>1))
	    {
	      EPI_CODE;
	      OP_CODE;
	      ET_SYM_CODE;
	      EPT_MIN_OP_CODE(GET_MIN_OP_3C)
	      CORNER_SYM_CODE;

	      tmp = dist1[EPMIN][CPSYM][CTSYM>>(D1_RS+1)];
	      dst = n + (((CTSYM>>D1_RS)&1) ? tmp>>4 : tmp&0xF);

	      if (dst > depth)
		continue;

	      tmp = dist2[EPMIN][CPSYM][m.etsym>>(D2_RS+1)];
	      dst = n + (((m.etsym>>D2_RS)&1) ? tmp>>4: tmp&0xF);
	
	      if (dst > depth)
		continue;
	    }

          EPR_MOV_CODE
	  m.epi = &ep_info[m.ep];
	  CP6C_MOV_CODE
	  seq[n] = mv;
	  search(&m, n+1, seq_gen[mv]);
	}
    }
}

void init()
{
  init3();
  seq[0] = NIL;
  load_dist_files();
}

int load_dist_files()
{
  char fname [50];

  if (USE_DIST1 == 0 || USE_DIST2 == 0)
    {
      printf("USE_DIST1 or USE_DIST2 is not set\n");
      exit(0);
    }

  snprintf(fname, DAT_FNAME_LEN, "dat/D1_%04dH_%02d%c.dat",
	   DIST1_SIZE, D1_GEN_DEPTH, metric);

  load_dist_file(fname, dist1, sizeof(dist1));

  snprintf(fname, DAT_FNAME_LEN, "dat/D2_%04dH_%02d%c.dat",
	   DIST2_SIZE, D2_GEN_DEPTH, metric);

  load_dist_file(fname, dist2, sizeof(dist2));

  return(0);
}
