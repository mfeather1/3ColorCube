// Author: Michael Feather
// This program shows the counts by depth for a given dist.dat file.

#include "rc.h"
#include <stdio.h>
#include <string.h>

#define MEG 1048576
#define MAX_FILE_SIZE (long)2000*MEG

unsigned char setb[12];
unsigned char dist[MAX_FILE_SIZE];

void bit_array_count();
void quad_array_count();
void hexd_array_count();
void show_dist_counts();
long get_distb_count();
void show_distq_counts();
void init();
void basename();

int main(argc, argv)
     int argc;
     char **argv;
{
  FILE *lfp;
  int type;
  long n;
  char fname[100], fname2[100];

  if (argc != 2)
    {
      printf("Usage: %s {file}\n", argv[0]);
      exit(0);
    }

  init();

  basename(fname, argv[1]);
  type = fname[7];

  if (type != 'H' && type != 'B' && type != 'Q')
    {
      printf("Invalid file type: %c\n", type);
      printf("Invalid file name: %s\n", argv[1]);
      exit(0);
    }

  if ((lfp = fopen(argv[1], "r")) == NULL)
    {
      snprintf(fname2, DAT_FNAME_LEN, "dat/%s", argv[1]);

      if ((lfp = fopen(fname2, "r")) == NULL)
	{
	  printf("Error opening file: <%s>\n", argv[1]);
	  exit(0);
	}
    }

  printf("%s: ", fname);
  fflush(stdout);
  n = fread(dist, 1, MAX_FILE_SIZE, lfp);
  fclose(lfp);

  if (n == MAX_FILE_SIZE)
    {
      printf("File is too large, increase MAX_FILE_SIZE\n");
      exit(1);
    }

  printf("%.0fM\n", (float)n/MEG);
  fflush(stdout);

  if (type == 'H')
    hexd_array_count(dist, n);

  else if (type == 'B')
    bit_array_count(dist, n);

  else if (type == 'Q')
    quad_array_count(dist, n);

  exit(0);
}

void init()
{
  int i, j;

  for (i=0, j=1; i < 8; i++, j*=2)
    setb[i] = j;
}

void basename(fname, s)
     char *fname, *s;
{
  int i;

  for (i=strlen(s); i > 0; i--)
    if (s[i] == '/')
      break;

  if (i > 0)
    strcpy(fname, &s[i+1]);
  else
    strcpy(fname, s);
}

void one_per_byte_count(dist, n)
     unsigned char *dist;
     long n;
{	
  printf("Counts:\n");
  fflush(stdout);
  show_dist_counts(dist, n, 0);
}

void bit_array_count(dist, n)
     unsigned char *dist;
     long n;
{	
  int count;

  printf("Count:\n");
  fflush(stdout);
  count = get_distb_count(dist, n);
  printf("%u\n", count);
  fflush(stdout);
}

void quad_array_count(dist, n)
     unsigned char *dist;
     long n;
{	
  printf("Quad Array Counts: (4 depths)\n");
  fflush(stdout);
  show_distq_counts(dist, n, 2);
}

void hexd_array_count(dist, n)
     unsigned char *dist;
     long n;
{	
  int ct[20], total=0;
  long i;

  printf("Counts:\n");
  fflush(stdout);

  for(i=0; i < 20; i++)
    ct[i] = 0;

  for (i=0; i < n; i++)
    {
      ct[dist[i]>>4]++;
      ct[dist[i]&0xF]++;
    }

  for(i=0; i <= 16; i++)
    {
      if (ct[i] != 0)
	{
	  total += ct[i];
	  printf("%5d %11d\n", i, ct[i]);
	}
    }

  printf("total %11d\n\n", total);
}
