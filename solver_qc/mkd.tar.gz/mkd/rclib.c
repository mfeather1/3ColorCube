// Author: Michael Feather

#include <sys/stat.h>
#include <string.h>
#include <ctype.h>

#include "rc.h"
#include "func.h"

long nodes[2];
char cw[3], ccw[3], flip[2];

void init1()
{
  int i, j, k;

  metric = 'F' ;

  for (i=0; i < 18; i++)
    ccw_mv[i] = (i%3)>1;

  flip[0] = 1;

  copy(cw,   "120", 3);
  copy(ccw,  "201", 3);
  copy(untwc,"021", 3);

  ctw[0]  = ctw[2]  = crtw;
  ctw[3]  = ctw[5]  = cltw;
  ctw[12] = ctw[14] = cftw;
  ctw[15] = ctw[17] = cbtw;
  etw[12] = etw[14] = eftw;
  etw[15] = etw[17] = ebtw;

  copy(cmv[0],  "07254163", 8);
  copy(cmv[3],  "61430527", 8);
  copy(cmv[6],  "51264307", 8);
  copy(cmv[9],  "04732561", 8);
  copy(cmv[12], "45231067", 8);
  copy(cmv[15], "01674532", 8);

  copy(emv[0],  "0A934567812B", 12);
  copy(emv[3],  "812B456739A0", 12);
  copy(emv[6],  "0123956847AB", 12);
  copy(emv[9],  "01234BA78956", 12);
  copy(emv[12], "5423016789AB", 12);
  copy(emv[15], "0167453289AB", 12);

  for (i=0; i < 2; i++)
    for (j=0; j < 18; j+=3)
      for (k=0; k < 8; k++)
	cmv[i+j+1][k] = cmv[i+j][cmv[j][k]];

  for (i=0; i < 2; i++)	
    for (j=0; j < 18; j+=3)
      for (k=0; k < 12; k++)
	emv[i+j+1][k] = emv[i+j][emv[j][k]];
}

void init2()
{
  int i, j, k;
  char s[20], tmp[20];

  init1();
  set_indexes();
  init_conv();
  init_seq();

  for (i=j=0; i < B2_MAX; i++)
    if (int_to_str_lim(i, s, 7, 2, 4))
      {
	b2_cp[i] = j;
	cp_b2[j++] = i;
      }
  for (i=j=0; i < B3_MAX; i++)
    if (int_to_str_lim(i, s, 11, 3, 4))
      {
	b3_ep[i] = j;
	ep_b3[j++] = i;
      }

  for (i=0; i < C_PRM; i++)
    {
      int_to_strp(cp_b2[i], s, 7, 2);

      for (j=0; j < MOVES; j++)
	{	
	  for (k=0; k < 8; k++)
	    tmp[k] = s[cmv[j][k]];
	  cp_mov[i][j] = b2_cp[str_to_int(tmp,7,2)];
	}		
    }
  populated("cp_mov");

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=0; j < 8; j++)
	tmp[j] = s[j]/4;

      cp6c_cp3c[i] = b2_cp[str_to_int(tmp,7,2)];
    }

  for (i=0; i < C_TWIST; i++)
    {
      int_to_strp(i,s,7,3);

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 7; k++)
	    tmp[k] = s[cmv[j][k]];

	  if (ctw[j])
	    ctw[j](tmp);

	  ct_mov[i][j] = str_to_int(tmp,7,3);
	}
    }
  populated("ct_mov");

  #if USE_EP_MOV
  for (i=0; i < E_PRM; i++)
    {
      int_to_strp(ep_b3[i], s, 11, 3);

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 12; k++)
	    tmp[k] = s[emv[j][k]];

	  ep_mov[i][j] = b3_ep[str_to_int(tmp,11,3)];
	}		
    }
  populated("ep_mov");
  #endif

  for (i=0; i < E_TWIST; i++)
    {
      int_to_strp(i,s,11,2);

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 11; k++)
	    tmp[k] = s[emv[j][k]];

	  if (etw[j])
	    etw[j](tmp);

	  et_mov[i][j] = str_to_int(tmp,11,2);
	}		
    }
  populated("et_mov");

  init_slice_map();
  populate_b2_slice();
  populate_ep_slice();
  populate_slice_ep();
  populate_cp6c_cpr();

  #if USE_EPR_MOV2
  populate_epr_mov2();
  #else
  populate_epr_mov();
  #endif
}

void init3()
{
  init2();

  load_text_file("dat/inv_op.dat", inv_op, CUBE_SYM, CHAR);
  load_text_file("dat/op_op.dat", op_op, CUBE_SYM*CUBE_SYM, CHAR);
  load_text_file("dat/ep_min_op.dat", ep_min_op, E_PRM, CHAR);
  load_text_file("dat/ep_min.dat", ep_min, E_PRM, INT);
  load_text_file("dat/cpt_min.dat", cpt_min, C_PRM_TW, SHORT);
  load_text_file("dat/cpt_min_op.dat", cpt_min_op, C_PRM_TW, CHAR);
  load_text_file("dat/cp6c_min_op.dat", cp6c_min_op, C_PERM, CHAR);
  load_text_file("dat/cp6c_min.dat", cp6c_min, C_PERM, INT);

  #if USE_ET_SYM
  if (ET_SYM_METHOD == 1)
    load_bin_file("dat/et_sym_m1.dat", et_sym, CUBE_SYM*E_TWIST, SHORT);
  else
    load_bin_file("dat/et_sym_m2.dat", et_sym, CUBE_SYM*E_TWIST, SHORT);
  #endif

  #if USE_ET_SYM_FR
  load_bin_file("dat/et_sym_fr.dat", et_sym_FR, SLICE_PRM*E_TWIST, SHORT);
  #endif

  #if USE_ET_SYM_UF
  load_bin_file("dat/et_sym_uf.dat", et_sym_UF, SLICE_PRM*E_TWIST, SHORT);
  #endif

  #if USE_CPT_SYM
  load_bin_file("dat/cpt_sym.dat", cpt_sym, MIN_CPT*CUBE_SYM, INT);
  #endif

  populate_min_ep();

  load_text_file("dat/op_mv.dat", op_mv, CUBE_SYM*MOVES, CHAR);

  populated("op_mv");

  #if USE_CPT_MOV
  populate_cpt_mov();
  #endif

  init_op16e();

  #if USE_EPT_MIN_OP
  load_text_file("dat/ept_op_idx.dat", ept_op_idx, E_PRM, INT);
  load_bin_file("dat/ept_min_op.dat", ept_min_op, N_EPT_MIN_OP*E_TWIST, CHAR);
  #endif

  load_ept_min_ops();
  populate_ept_ops_indexes();
  populate_ep_info();

  #if USE_EPR_SYM2
  load_bin_file("dat/epr_sym2.dat", epr_sym2, N_EPR_SYM2*24, CHAR);
  load_bin_file("dat/epr_idx.dat", epr_idx, 3*CUBE_SYM*SLICE_PRM, CHAR);
  populated("epr_sym2");
  #else
  load_bin_file("dat/epr_sym.dat", epr_sym, 3*CUBE_SYM*SLICE_PRM*24, CHAR);
  #endif

  #if USE_CP_SYM
  load_bin_file("dat/cp_sym.dat", cp_sym, C_PRM*CUBE_SYM, CHAR);
  #endif

  #if USE_CT_SYM
  load_bin_file("dat/ct_sym.dat", ct_sym, C_PRM*C_TWIST*CUBE_SYM, SHORT);
  #endif

  #if USE_CPT_SYM
  load_bin_file("dat/cpt_sym.dat", cpt_sym, MIN_CPT*CUBE_SYM, INT);
  #endif

  #if USE_CP6C_MOV
  populate_cp6c_mov();
  #endif

  #if USE_CP6C_INFO
  populate_cp6c_info();
  #endif

  #if USE_ET_FR
  populate_et_fr();
  #endif
}

#if USE_CP6C_MOV
void populate_cp6c_mov()
{
  int i, j, k;

  char s[8], tmp[8];

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=0; j < 8; j++)
	tmp[j] = s[j]/4;

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 8; k++)
	    tmp[k] = s[cmv[j][k]];

	  cp6c_mov[i][j] = perm_to_int(tmp, 8);
	}
    }
  populated("cp6c_mov");
}
#endif

void populate_min_cp6c()
{
  int i, n;

  dependency("cp6c_min_op", "populate_min_cp6c");

  for (i=n=0;  n < C_PERM; n++)
    if (cp6c_min_op[n] == 0)
      min_cp6c[i++] = n;

  populated("min_cp6c");
}

void populate_ep_info()
{
  int i;

  dependency("ep_slice", "populate_ep_info");
  dependency("ep_min", "populate_ep_info");
  dependency("ep_min_op", "populate_ep_info");
  dependency("ept_op_idx", "populate_ep_info");

  for (i=0; i < E_PRM; i++)
    {
      ep_info[i].op_ix = ept_op_idx[i];
      ep_info[i].op = ep_min_op[i];
      ep_info[i].min = ep_min[i];
      ep_info[i].s0 = ep_slice[i][0];
      ep_info[i].s1 = ep_slice[i][1];
      ep_info[i].s2 = ep_slice[i][2];
    }

  populated("ep_info");
}

#if USE_CPT_MOV
void populate_cpt_mov()
{
  int cp, ct, i, j, cpm, ctm, cptm, idx;
  char cps[8], cts[8], tmp[8];

  for (cp=0; cp < C_PRM; cp++)
    {
      int_to_strp(cp_b2[cp], cps, 7, 2);

      for (ct=0; ct < C_TWIST; ct++)
	{
	  idx = cp*C_TWIST + ct;

	  if (cpt_min_op[idx] != 0)
	    continue;

	  int_to_strp(ct, cts, 7, 3);

	  for (i=0; i < MOVES; i++)
	    {
	      for (j=0; j < 8; j++)
		tmp[j] = cps[cmv[i][j]];

	      cpm = b2_cp[str_to_int(tmp,7,2)];

	      for (j=0; j < 8; j++)
		tmp[j] = cts[cmv[i][j]];

	      if (ctw[i])
		ctw[i](tmp);

	      ctm = str_to_int(tmp,7,3);
	      cptm = cpm*C_TWIST + ctm;
	      cpt_mov[cpt_min[idx]][i].min = cpt_min[cptm];
	      cpt_mov[cpt_min[idx]][i].op= inv_op[cpt_min_op[cptm]];
	    }
	}
    }

  populated("cpt_mov");
}
#endif

void init_seq()
{
  int i;
  mvlist1[0] = 0;
  mvlist1[1] = 1;
  mvlist1[2] = NIL;
  for (i=0; i < MOVES; i++)
    mvlist2[i] = i;
  mvlist2[i] = NIL;
  init_seq_gen(6,3);
}

void init_seq_gen(x, y)
     int x, y;
{
  int i, j, k;

  for (i=0; i < MOVES; i++)
    {
      for (j=k=0; j < i/x*x; j++)
	seq_gen[i][k++] = j;

      for (j=i/y*y+y; j < MOVES; j++)
	seq_gen[i][k++] = j;

      seq_gen[i][k] = NIL;
    }
}

void cbtw(s)
     char *s;
{
  s[7] = cw[s[7]];	
  s[2] = ccw[s[2]];
  s[6] = cw[s[6]];	
  s[3] = ccw[s[3]];
}

void cltw(s)
     char *s;
{
  s[2] = cw[s[2]];	
  s[4] = ccw[s[4]];
  s[0] = cw[s[0]];	
  s[6] = ccw[s[6]];
}

void crtw(s)
     char *s;
{
  s[1] = cw[s[1]];	
  s[7] = ccw[s[7]];
  s[3] = cw[s[3]];	
  s[5] = ccw[s[5]];
}

void cftw(s)
     char *s;
{
  s[4] = cw[s[4]];	
  s[1] = ccw[s[1]];
  s[5] = cw[s[5]];	
  s[0] = ccw[s[0]];
}

void ebtw(s)
     char *s;
{
  s[3] = flip[s[3]];	
  s[6] = flip[s[6]];
  s[2] = flip[s[2]];	
  s[7] = flip[s[7]];
}

void eftw(s)
     char *s;
{
  s[0] = flip[s[0]]; 	
  s[5] = flip[s[5]];
  s[1] = flip[s[1]]; 	
  s[4] = flip[s[4]];
}

void set_indexes()
{
  /*         00 01 02
             03 04 05
             06 07 08
    09 10 11 12 13 14 15 16 17 18 19 20
    21 22 23 24 25 26 27 28 29 30 31 32
    33 34 35 36 37 38 39 40 41 42 43 44
             45 46 47
             48 49 50
             51 52 53
  */

  char center_idx_init[6]={4,22,25,28,31,49};

  char 	corner_idx_init[8][3] =
    {
       6, 12, 11,
      47, 38, 39,
      51, 44, 33,
       2, 18, 17,
      45, 35, 36,
       8, 15, 14,
       0,  9, 20,
      53, 41, 42
    };

  char 	edge_idx_init[12][2] =
    {
      24, 23,
      26, 27,
      30, 29,
      32, 21,
       7, 13,
      46, 37,
      52, 43,
       1, 19,
       3, 10,
       5, 16,
      50, 40,
      48, 34
    };

  int i, j;

  for (i=0; i < 6; i++)
    center_idx[i] = center_idx_init[i];

  for (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cnr_idx[i][j] = corner_idx_init[i][j];

  for (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      edg_idx[i][j] = edge_idx_init[i][j];
}

void set_colors_6c(r, f, u, l, b, d)
     char r, f, u, l, b, d;
{
  int i, j;

  /*
    Corners:	
    --------------------------------------
    Front   Back (looking thru cube)
    0 5     6 3
    4 1     2 7
    --------------------------------------
    1st digit = position
    2nd digit = twist (1 = clockwise, 2 = counter-clockwise)
            60  30
            00  50
    61  02  01  52  51  32  31  62
    22  41  42  11  12  71  72  21
            40  10
            20  70
  */

  char *cnr_loc[8][3] =
    {
      &u, &f, &l,
      &d, &f, &r,
      &d, &b, &l,
      &u, &b, &r,
      &d, &l, &f,
      &u, &r, &f,
      &u, &l, &b,
      &d, &r, &b
    };

  /*
    Edges:
    --------------------------------------
    Front      Middle      Back
      4        8   9         7
    0   1                  3   2
      5        B   A         6
    --------------------------------------

    1st digit = position
    2nd digit = twist (0 = sane, 1 = flipped)
             70
           80  90
             40
      81     41     91     71
    31  01 00  10 11  21 20  30
      B1     51     A1     61
             50
           B0  A0
             60
  */

  char *edg_loc[12][2] =
    {
      &f, &l,
      &f, &r,
      &b, &r,
      &b, &l,
      &u, &f,
      &d, &f,
      &d, &b,
      &u, &b,
      &u, &l,
      &u, &r,
      &d, &r,
      &d, &l
    };

  for (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cnr[i][j] = *cnr_loc[i][j];

  for (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      edg[i][j] = *edg_loc[i][j];
}

int convert_cnr_6c(s, cps, cts)
     char *s, *cps, *cts;
{
  int  i, x, y, z;
  char L, D, B, R, U, F;

  L = s[22];    D = s[49];    B = s[31];
  R = s[28];    U = s[4];     F = s[25];

  set_colors_6c(R, F, U, L, B, D);

  for (i=0; i < 8; i++)
    {
      x = s[cnr_idx[i][0]];
      y = s[cnr_idx[i][1]];
      z = s[cnr_idx[i][2]];

      if (x == U || x == D)
	{
	  cts[i] = 0;
	  cps[i] = get_cps(x,y,z);
	}
      else if (y == U || y == D)
	{
	  cts[i] = 1;
	  cps[i] = get_cps(y,z,x);
	}
      else
	{
	  cts[i] = 2;
	  cps[i] = get_cps(z,x,y);
	}
    }
  return(perm_to_int(cps,8));
}

int get_cps(a, b, c)
     char a, b, c;
{
  int i;

  for (i=0; i < 8; i++)
    if ((cnr[i][0] == a) && (cnr[i][1] == b) && (cnr[i][2] == c))
      return(i);
}	

void convert_edg_6c(s, eps, ets)
     char *s, *eps, *ets;
{	
  int i, x, y;
  char L, D, B, R, U, F;

  L = s[22];    D = s[49];    B = s[31];
  R = s[28];    U = s[4];     F = s[25];

  set_colors_6c(R, F, U, L, B, D);

  for (i=0; i < 12; i++)
    {
      x = s[edg_idx[i][0]];
      y = s[edg_idx[i][1]];

      if ((x == U || x == D) ||
	  ((x == F || x == B) && (y == L || y == R)))
	{
	  ets[i] = 0;
	  eps[i] = get_eps(x, y);
	}
      else
	{
	  ets[i] = 1;
	  eps[i] = get_eps(y, x);
	}
    }
}

int get_eps(a, b)
     char a, b;
{
  int i;

  for (i=0; i < 12; i++)
    if ((edg[i][0] == a) && (edg[i][1] == b))
      return(i);
}	

void populate_cp6c_cpr()
{
  char s[8], t1[8], t2[8];
  int i, j, x1, x2;

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=x1=x2=0; j < 8; j++)
	if (s[j]/4 == 0)
	  t1[x1++] = s[j];
	else
	  t2[x2++] = s[j]-4;

      cp6c_cpr[i] = perm_to_int(t1,4)*24 + perm_to_int(t2,4);
    }
  populated("cp6c_cpr");
}

void ep6c_epr(s, epr)
     char *s, *epr;
{
  char t0[4], t1[4], t2[4];
  int i, x0, x1, x2;

  /* example:

       ep6c: 3768B9042A15
       ep3c: 011222010201
             ------------
     epr[0]: 3     0 2 1   3021 -> 19
     epr[1]:  32    0   1  3201 -> 22
     epr[2]:    031   2    0312 ->  4
 */

  for (i=x0=x1=x2=0; i < 12; i++)
    if (s[i]>>2 == 0)
      t0[x0++] = s[i];
    else if (s[i]>>2 == 1)
      t1[x1++] = s[i]-4;
    else
      t2[x2++] = s[i]-8;		

  epr[0] = perm_to_int(t0, 4);
  epr[1] = perm_to_int(t1, 4);
  epr[2] = perm_to_int(t2, 4);
}

void show_dist_counts(dist, n, min)
     unsigned char *dist;
     int n, min;
{
  int i, count[20], total=1;

  dist[0] = 0;

  for (i=0; i < 20; i++) 	
    count[i] = 0;

  for (i=0; i < n; i++) 	
    count[dist[i]]++;

  for (i=1; i < 20; i++)	
    total += count[i];

  for (i=min; i < 20; i++)
    if (count[i] != 0)
      show_dist_count_line(i, count[i]);

  fflush(stdout);
}

void show_dist_count_line(mv, count)
     int mv, count;
{
  printf("%5d    %9d\n", mv, count);
  fflush(stdout);
}

void copy(dst, src, n)
     char *dst, *src;
     int n;
{	
  int i;
  for(i=0; i < n; i++)
    dst[i] = src[i] - ((src[i] > '9') ? 55 : 48);
}

long load_dist_file(fname, arr, n)
     char *fname;
     unsigned char *arr;
     long n;
{	
  long ret;
	
  printf("Loading %s: ", (char*)fname+4);
  printf("%3.0f MB\n", (float)n/MEG);
  fflush(stdout);
  ret = load_bin_file(fname, arr, n, CHAR);
  fflush(stdout);
  return(ret);
}

int parity(s, len)
     char *s, len;
{
  int i, n;
  char x, tmp[12];

  for (i = 0; i < len; i++)
    tmp[i] = s[i];

  for (i=n=0; i < len; i++)
    while (tmp[i] != i)
      {	
	x = tmp[i];
	tmp[i] = tmp[x];
	tmp[x] = x;
	n++;
      }

  return(n%2);
}

void load_ept_min_ops()
{	
  int i, j, n, ix;

  open_file("dat/ept_min_ops.dat", "r");

  for (i=ix=0; i < N_EPT_MIN_OPS; i++)
    {
      for (j=0; j < 3; j++)
	fscanf(fp, "%d", &ept_min_ops[i][j]);

      n = ept_min_ops[i][2];
      n = (n == CUBE_SYM-1) ? 0 : n+3;

      for (j=3; j < n; j++)
	fscanf(fp, "%2d ", &ept_min_ops[i][j]);
    }

  fclose(fp);
  populated("ept_min_ops");
}

void populate_ept_ops_indexes()
{
  int i, j, ep, ix;

  dependency("ept_min_ops", "populate_ept_ops_indexes");

  for (i=0; i < MIN_EP; i++)
    ept_ops_ix1[i] = NIL;

  for (i=0; i < N_EPT_OPS_IX2; i++)
    for (j=0; j < E_TWIST; j++)
      ept_ops_ix2[i][j] = NIL;

  for (i=ix=0; i < N_EPT_MIN_OPS; i++)
    {
      ep = ep_min[ept_min_ops[i][0]];

      if (ept_ops_ix1[ep] == NIL)
	ept_ops_ix1[ep] = ix++;

      ept_ops_ix2[ix-1][ept_min_ops[i][1]] = i;
    }

  populated("op_info");
  populated("ept_ops_ix1");
  populated("ept_ops_ix2");
}

int chk_dup_3c(ep, et, cp, ct, n)
     int ep, et, cp, ct, n;
{	
  int i, ept, cpt;
  static int cfg[CFG_LIST_3C][3];

  ept = ep*E_TWIST + et;
  cpt = cp*C_TWIST + ct;

  for (i=0; i < cfg_idx; i++)
    if (cfg[i][0] == ept && cfg[i][1] == cpt && cfg[i][2] <= n)
      return(1);

  if (cfg_idx >= CFG_LIST_3C)
    {
      printf("ERROR: Max size exceeded in chk_dup_3c()\n");
      fflush(stdout);
      exit(1);
    }

  cfg[cfg_idx][0] = ept;
  cfg[cfg_idx][1] = cpt;
  cfg[cfg_idx++][2] = n;

  return(0);
}

void show_distq_counts(dist, n, max_depth)
     unsigned char *dist;
     long n;
     int max_depth;
{
  long ct[20];

  for (int i=0; i < 20; i++)
    ct[i] = 0;

  for (long i=0; i < n; i++)
    for (int j=0; j < 8; j+=2)
      ct[(dist[i]>>j)&3]++;

  for (int i=0; i < 4; i++)
    printf("%5d   %10ld\n", i+max_depth-2, ct[i]);

  fflush(stdout);
}

long get_distb_count(dist, n)
     unsigned char *dist;
     long n;
{
  int j, k;
  long count;
  unsigned char bits[256];

  for (int i=0; i < 256; i++)
    for (j=0, k=1, bits[i]=0; j < 8; j++, k*=2)
      if (i & k) bits[i]++;

  for (long i=count=0; i < n; i++)
    count += bits[dist[i]];
  return(count);
}

void init_op16e()
{
  int i, j, op1, op2;
  char op_fb[16] = {0,5,6,7,8,21,22,23,24,29,30,31,32,45,46,47};

  for (i=0; i < 2; i++)
    {
      op1 = (i) ? OP_UF : OP_FR;

      for (j=0; j < 16; j++)
	{
	  op2 = op_fb[j];
	  op16e[op_op[op1][op2]].op1 = op1;
	  op16e[op_op[op1][op2]].op2 = op2;
	}
    }
  populated("op16e");
}

void populate_b2_slice()
{
  int c, i, j, k;
  char s[12];

  for (i=k=0; i < 4096; i++)
    {
      int_to_str(i, s, 12, 2);

      for (c=j=0; j < 12; j++)
	if (s[j] == 1)
	  c++;

      if (c == 4)
        b2_slice[i] = k++;

    }
}

void populate_ep_slice()
{
  int i, j, k;
  char s[12], t[12];

  for (i=0; i < E_PRM; i++)
    {
      int_to_strp(ep_b3[i], s, 11, 3);

      for (j=0; j < 3; j++)
	{
	  for (k=0; k < 12; k++)
	    t[k] = (s[k] == j) ? 1 : 0;

	  ep_slice[i][j] = b2_slice[str_to_int(t, 12, 2)];
	}
    }
  populated("ep_slice");
}

void init_slice_map()
{
  int i, j;
  char slice_map_init[CUBE_SYM][3] =
    {
      0,1,2,0,2,1,1,2,0,0,2,1,1,2,0,0,1,2,1,0,2,0,1,2,
      1,0,2,0,2,1,1,2,0,0,2,1,1,2,0,2,1,0,2,0,1,2,1,0,
      2,0,1,2,1,0,2,0,1,2,1,0,2,0,1,1,0,2,0,1,2,1,0,2,
      0,1,2,0,2,1,1,2,0,0,2,1,1,2,0,0,1,2,1,0,2,0,1,2,
      1,0,2,0,2,1,1,2,0,0,2,1,1,2,0,2,1,0,2,0,1,2,1,0,
      2,0,1,2,1,0,2,0,1,2,1,0,2,0,1,1,0,2,0,1,2,1,0,2
    };
  for (i=0; i < CUBE_SYM; i++)
    for (j=0; j < 3; j++)
      slice_map[i][j] = slice_map_init[i][j];
}

void populate_slice_ep()
{
  int c, i, j, ix;
  char a[12], b[12];

  for (i=ix=0; i < 4096; i++)
    {
      int_to_str(i, a, 12, 2);

      for (c=j=0; j < 12; j++)
        if (a[j] == 1)
          c++;

      if (c == 4)
        {
          memcpy(b, a, 12);

          for (j=0; j < 12; j++)
            b[j] = b[j] ? 0 : 1;

          for (c=j=0; j < 12; j++)
            if (b[j] == 1 && c++ >= 4)
              b[j] = 2;

          slice_ep[ix][0] = b3_ep[str_to_int(b,11,3)];
          memcpy(b, a, 12);

          for (c=j=0; j < 12; j++)
            if (b[j] == 0 && c++ >= 4)
              b[j] = 2;

          slice_ep[ix][1] = b3_ep[str_to_int(b,11,3)];
          memcpy(b, a, 12);

          for (j=0; j < 12; j++)
            if (b[j])
              b[j] = 2;

          for (c=j=0; j < 12; j++)
            if (b[j] == 0 && c++ >= 4)
              b[j] = 1;

          slice_ep[ix++][2] = b3_ep[str_to_int(b,11,3)];
        }
    }
}

void mk_eps_6c(eps_6c, eps_3c, s)
     char *eps_6c, *eps_3c, *s;
{
  int i, x, y, z;

  for (i=x=0, y=4, z=8; i < 12; i++)
    {
      if (eps_3c[i] == 0)
	eps_6c[i] = s[x++];

      else if (eps_3c[i] == 1)
	eps_6c[i] = s[y++] + 4;

      else if (eps_3c[i] == 2)
	eps_6c[i] = s[z++] + 8;
    }
}

void mk_hexd_arr(arr, n)
     unsigned char *arr;
     int n;
{
  int i;

  for (i=0; i < n; i+=2)
    arr[i/2] = arr[i+1]*16 + arr[i];
}

int check_gen_depth(n, use_dist, dist_depth)
     int n;
     char *use_dist, *dist_depth;
{
  if (use_dist[n])
    if (dist_depth[n] < 1 || dist_depth[n] > 15)
      {
	printf("ERROR: Invalid D%d_GEN_DEPTH: %d, range is 1-15\n",
	       n, dist_depth[n]);
	return(1);
      }
  return(0);
}

void make_cubestr(cubestr, cube)
     char *cubestr;
     struct s_cube *cube;
{
  int i, j;

  for (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      cubestr[edg_idx[i][j]] = edg[cube->eps[i]][(cube->ets[i]+j)%2];

  for (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cubestr[cnr_idx[i][j]] = cnr[cube->cps[i]][(untwc[cube->cts[i]]+j)%3];
}

void make_eps(char *eps, int ep, char *epr) {
  char eps_3c[12], eps_3r[12], ix[3] = {0,0,0};
  int_to_strp(ep_b3[ep], eps_3c, 11, 3);
  for (int i=0; i < 3; i++)
    int_to_perm(epr[i], &eps_3r[i*4], 4);
  for (int i=0, n=0; i < 12; i++, ix[n]++) {
    n = eps_3c[i];
    eps[i] = n*4 + eps_3r[n*4+ix[n]];
  }
}

void show_cube(centers, ep, epr, et, cp6c, ct)
     char *centers, *epr;
     int ep, et, cp6c, ct;
{
  int i;
  struct s_cube cube;
  char cubestr[FACELETS];

  for (i=0; i < 6; i++)
    cubestr[center_idx[i]] = centers[i];

  int_to_strp(ep_b3[ep], cube.ep, 11, 3);
  int_to_strp(et, cube.ets, 11, 2);
  int_to_perm(cp6c, cube.cps, 8);
  int_to_strp(ct, cube.cts, 7, 3);

  make_eps(cube.eps, 0, epr);

  make_cubestr(cubestr, &cube);
  show_cubestr(cubestr, 0);
}

void show_cubestr(s, f)
     char *s, f;
{	
  int i, j;

  if (f)
    {
      for (i=0; i < FACELETS; i++)
	printf("%c", s[i]);

      printf("\n");
      return;
    }

  for (i=0; i < 9; i+=3)
    printf("    %c%c%c\n",   s[i], s[i+1], s[i+2]);

  for (; i < 45; i+=12)
    {
      for (j=0;  j < 12; j+=3)
	printf("%c%c%c ", s[i+j], s[i+j+1], s[i+j+2]);
      printf("\n");
    }

  for (; i < 54; i+=3)
    printf("    %c%c%c\n",   s[i], s[i+1], s[i+2]);

  printf("\n");
}

void populate_min_ep()
{
  int i, ep;

  for (ep=i=0; ep < E_PRM; ep++)
    if (ep_min_op[ep] == 0)
      min_ep[i++] = ep;

  populated("min_ep");
}

void get_eprsym(eprsym, ep, epr, op)
     char *eprsym, *epr;
     int ep, op;
{
  for (int i=0; i < 3; i++)
    {
      eprsym[slice_map[op][i]] =
        #if USE_EPR_SYM2
        epr_sym2[epr_idx[op][ep_slice[ep][i]][i]][epr[i]];
        #else
        epr_sym[op][ep_slice[ep][i]][epr[i]][i];
        #endif
    }
}

void init_map(map, op_FR, op_UR, reflect)
     char map[CUBE_SYM][FACELETS], *op_FR, *op_UR, *reflect;
{
  int i;

  for (i=0; i < FACELETS; i++)
    map[0][i] = i;

  memcpy(map[1],  op_FR,FACELETS);
  memcpy(map[21], op_UR,FACELETS);
  sym_op(map[2],  map[1],  op_UR);
  sym_op(map[3],  map[2],  op_UR);
  sym_op(map[4],  map[3],  op_UR);
  sym_op(map[5],  map[1],  op_FR);
  sym_op(map[6],  map[5],  op_UR);
  sym_op(map[7],  map[6],  op_UR);
  sym_op(map[8],  map[7],  op_UR);
  sym_op(map[9],  map[5],  op_FR);
  sym_op(map[10], map[9],  op_UR);
  sym_op(map[11], map[10], op_UR);
  sym_op(map[12], map[11], op_UR);
  sym_op(map[13], map[2],  map[9]);
  sym_op(map[14], map[13], op_UR);
  sym_op(map[15], map[14], op_UR);
  sym_op(map[16], map[15], op_UR);
  sym_op(map[17], map[7],  map[13]);
  sym_op(map[18], map[17], op_UR);
  sym_op(map[19], map[18], op_UR);
  sym_op(map[20], map[19], op_UR);
  sym_op(map[22], map[21], op_UR);
  sym_op(map[23], map[22], op_UR);
  memcpy(map[24], reflect, FACELETS);

  for (i=25; i < CUBE_SYM; i++)
      sym_op(map[i], map[i-24], reflect);
}

void sym_op(dst, src, op)
     char *dst, *src, *op;
{
  int i;

  for (i=0; i < FACELETS; i++)
      dst[i] = src[op[i]];
}

#if USE_EPR_MOV2 == 0
void populate_epr_mov()
{
  int i, j, k, n, x, mv;
  char s[12]={0,1,2,3,0,1,2,3,0,0,0,0};
  char t[12], eps_3c[12], eps_6c[12];

  for (mv=0; mv < MOVES; mv++)
      for (i=0; i < SLICE_PRM; i++)
	{
	  int_to_strp(ep_b3[slice_ep[i][2]], eps_3c, 11, 3);
	
	  for (j=0; j < 24; j++)
	    {
	      int_to_perm(j, &s[8], 4);
	      mk_eps_6c(eps_6c, eps_3c, s);

	      for (k=x=0; k < 12; k++)
		{
		  n = eps_6c[emv[mv][k]]-8;

		  if (n >= 0)
		    t[x++] = n;
		}

	      epr_mov[i][j][mv] =perm_to_int(t, 4);
	    }
	}
  populated("epr_mov");
}
#endif

#if USE_EPR_MOV2
void populate_epr_mov2()
{
  int i, j, k, ix, mv;
  char s[12]={0,1,2,3,0,1,2,3,0,1,2,3};
  char t[12], epr[3];
  char tmp_map[24], eps_3c[12], eps_6c[12];

  for (mv=0; mv < MOVES; mv++)
    {
      for (i=0; i < SLICE_PRM; i++)
	{
	  int_to_strp(ep_b3[slice_ep[i][2]], eps_3c, 11, 3);
	
	  for (j=0; j < 24; j++)
	    {
	      int_to_perm(j, &s[8], 4);
	      mk_eps_6c(eps_6c, eps_3c, s);
	
	      for (k=0; k < 12; k++)
		t[k] = eps_6c[emv[mv][k]];
	
	      ep6c_epr(t, epr);
	      tmp_map[j] = epr[2];

	      if (j == 0)
		{
		  ix = tmp_map[0];
		  epr_mov_idx[i][mv] = ix;
		
		  if (epr_mov2[ix][0] != 0)
		    break;
		}
	    }

	  if (epr_mov2[ix][0] == 0)
	    memcpy(epr_mov2[ix], tmp_map, 24);
	}
    }
  populated("epr_mov2");
  populated("epr_mov_idx");
}
#endif

int load_cube(fname, s)
     char *fname, *s;
{
  int n;

  open_file(fname, "r");
  n = load_cube_fp(fp, s);
  fclose(fp);
  return(n);
}

int load_cube_fp(fp, s)
     FILE *fp;
     char *s;
{	
  int i, len;

  for (i=0; i < FACELETS; i++)
    {
      if (fscanf(fp, " %c", &s[i]) == EOF)
	break;
      s[i] = toupper(s[i]);
    }

  fflush(fp);
  len = i;

  if (len > 0 && len < FACELETS)
    {
      printf("\nERROR: Incomplete Cube Entered (%d of 54 facelets):", len);
      printf("\n       Data Read: ");

      for (i=0; i < len; i++)
	printf("%c", s[i]);

      printf("\n");
    }

  return(i);
}

#if USE_CHK_DUP_6C
int chk_dup_6c(ep, et, epr, cp, ct, n)
     int ep, et, epr, cp, ct, n;
{	
  int i, ept, cpt;
  static int cfg[CFG_LIST_6C][4];

  ept = ep*E_TWIST + et;
  cpt = cp*C_TWIST + ct;

  for (i=0; i < cfg_idx; i++)
    if (cfg[i][0] == ept && cfg[i][1] == epr &&
	cfg[i][2] == cpt && cfg[i][3] <= n)
      return(1);

  if (cfg_idx >= CFG_LIST_6C)
    {
      printf("ERROR: Max size exceeded in chk_dup_6c()\n");
      fflush(stdout);
      exit(1);
    }

  cfg[cfg_idx][0] = ept;
  cfg[cfg_idx][1] = epr;
  cfg[cfg_idx][2] = cpt;
  cfg[cfg_idx++][3] = n;

  return(0);
}
#endif

#if USE_GET_EPRSYM_M1
void get_eprsym_m1(sym, epi, epr, op)
char *sym, *epr, op;
struct s_info *epi;
{
  sym[slice_map[op][0]] = epr_sym[op][epi->s0][epr[0]][0];
  sym[slice_map[op][1]] = epr_sym[op][epi->s1][epr[1]][1];
  sym[slice_map[op][2]] = epr_sym[op][epi->s2][epr[2]][2];
}
#endif

#if USE_GET_EPRSYM_M2
void get_eprsym_m2(sym, epi, epr, op)
char *sym, *epr, op;
struct s_info *epi;
{
  sym[slice_map[op][0]] = epr_sym2[epr_idx[op][epi->s0][0]][epr[0]];
  sym[slice_map[op][1]] = epr_sym2[epr_idx[op][epi->s1][1]][epr[1]];
  sym[slice_map[op][2]] = epr_sym2[epr_idx[op][epi->s2][2]][epr[2]];
}
#endif

#if USE_GET_MIN_OP_E6C
void get_min_op_e6c(c)
struct S_CUBE *c;
{	
  char eprsym[3], eprtmp[3];
  int i, n, dif, min_op;
  int oplist[CUBE_SYM];
  long long min, sym;
  struct s_info *epi;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
	c->op = epr_min_op[EPR(c->epr)];
	return;
    }

  for (i=0; i < n; i++)
    oplist[i] = ept_min_ops[c->ops_idx][i+3];

  GET_EPRSYM(eprtmp, c->epi, c->epr, c->op_ept);
  epi = &ep_info[min_ep[c->epi->min]];
  min = EPR(eprtmp);

  for (i=dif=0; i < n; i++)
    {
      GET_EPRSYM(eprsym, epi, eprtmp, oplist[i]);
      sym = EPR(eprsym);

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op_ept][min_op];
}
#endif

#if USE_EPR_MIN_OP
void populate_epr_min_op()
{
  int ix=0, op, min, min_op, EPRsym;
  struct s_info *epi;
  char epr[3], eprsym[3];

  epi = &ep_info[0];

  for (epr[0]=0; epr[0] < 24; epr[0]++)
    for (epr[1]=0; epr[1] < 24; epr[1]++)
      for (epr[2]=0; epr[2] < 24; epr[2]++)
	{
	  min = EPR(epr);
	  min_op = 0;

	  for (op=1; op < CUBE_SYM; op++)
	    {
	      GET_EPRSYM(eprsym, epi, epr, op);

	      EPRsym = EPR(eprsym);


	      if (EPRsym < min)
		{
		  min = EPRsym;
		  min_op = op;
		}
	    }

	  epr_min_op[ix++] = min_op;
	}

  populated("epr_min_op");
}
#endif

char get_dist_type(n)
     int n;
{
  if (n == 0)
    return('B');
  else if (n == 1)
    return('Q');
  else
    return('H');

}

void show_populated()
{
  int i;

  for (i=0; i < pop_list_ix; i++)
    printf("%s\n", pop_list[i]);
}

void populated(arr)
char *arr;
{
  int i;

  for (i=0; i < pop_list_ix; i++)
    if (strncmp(pop_list[i], arr, N_POP_WIDTH) == 0)
      break;

  if (i == N_POP_LIST)
    {
      printf("ERROR: POP_LIST must be increased\n");
      exit(1);
    }

  if (i == pop_list_ix)
    {
      if (SHOW_DEPENDENCY_MSGS)
	  printf("DEP: Adding %s\n", arr);

      strncpy(pop_list[i], arr, N_POP_WIDTH);
      pop_list_ix++;
    }
}

void dependency(arr, func)
char *arr, *func;
{
  int i;

  if (SHOW_DEPENDENCY_MSGS)
    printf("DEP: Checking %s\n", arr);

  for (i=0; i < pop_list_ix; i++)
    if (strncmp(pop_list[i], arr, N_POP_WIDTH) == 0)
      return;

  printf("ERROR: prerequisite array [%s] is not populated\n", arr);
  printf("       caller: %s()\n", func);
  exit(1);
}

#if USE_CP6C_INFO
void populate_cp6c_info()
{
  int i;

  for (i=0; i < C_PERM; i++)
    {
      cp6c_info[i].min = cp6c_min[i];
      cp6c_info[i].op = cp6c_min_op[i];
    }
}
#endif

void show_methods()
{
  printf("  ET_SYM_METHOD    = %d\n", ET_SYM_METHOD);
  printf("  CT_SYM_METHOD    = %d\n", CT_SYM_METHOD);
  printf("  EPR_MOV_METHOD   = %d\n", EPR_MOV_METHOD);
  printf("  EPR_SYM_METHOD   = %d\n", EPR_SYM_METHOD);
}

#if USE_GET_MIN_OP_3C_M1
void get_min_op_3c_m1(c)
struct S_CUBE *c;
{	
  int i, n, dif, min, min_op, sym, cpsav, ctsav, cpsym, ctsym;
  struct s_cpt csym;
  unsigned short *oplist;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
      c->op = cpt_min_op[c->cp*C_TWIST+c->ct];
      return;
    }

  oplist = &ept_min_ops[c->ops_idx][3];

  cpsav = cp_sym[c->cp][c->op];
  ctsav = ct_sym[c->cp][c->ct][c->op];
  min = (cpsav<<16) + ctsav;

  for (i=dif=0; i < n; i++)
    {
      cpsym = cp_sym[cpsav][oplist[i]];
      ctsym = ct_sym[cpsav][ctsav][oplist[i]];
      sym = (cpsym<<16) + ctsym;

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op][min_op];
}
#endif

#if USE_GET_MIN_OP_3C_M2
void get_min_op_3c_m2(c)
struct S_CUBE *c;
{	
  int i, n, dif, min, min_op, sym;
  unsigned short *oplist;
  struct s_min cpt;
  struct s_cpt csym;

  cpt = c->cpt;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
      c->op = inv_op[cpt.op];
      return;
    }

  oplist = &ept_min_ops[c->ops_idx][3];

  cpt.op = op_op[cpt.op][c->op];
  csym = cpt_sym[cpt.min][cpt.op];
  min = (csym.cp<<16) + csym.ct;

  for (i=dif=0; i < n; i++)
    {
      csym = cpt_sym[cpt.min][op_op[cpt.op][oplist[i]]];
      sym = (csym.cp<<16) + csym.ct;

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op][min_op];
}
#endif

#if USE_EPR_SYM_M1
int epr_sym_m1(c)
struct S_CUBE *c;
{
  char eprsym[3];
  eprsym[slice_map[c->op][0]] = epr_sym[c->op][EP0][c->epr[0]][0];
  eprsym[slice_map[c->op][1]] = epr_sym[c->op][EP1][c->epr[1]][1];
  eprsym[slice_map[c->op][2]] = epr_sym[c->op][EP2][c->epr[2]][2];
  return((eprsym[0] * 24 + eprsym[1]) * 24 + eprsym[2]);
}
#endif

#if USE_EPR_SYM_M2
int epr_sym_m2(c)
  struct S_CUBE *c;
{
  char eprsym[3];
  eprsym[slice_map[c->op][0]] = epr_sym2[epr_idx[c->op][EP0][0]][c->epr[0]];
  eprsym[slice_map[c->op][1]] = epr_sym2[epr_idx[c->op][EP1][1]][c->epr[1]];
  eprsym[slice_map[c->op][2]] = epr_sym2[epr_idx[c->op][EP2][2]][c->epr[2]];
  return((eprsym[0] * 24 + eprsym[1]) * 24 + eprsym[2]);
}
#endif

#if USE_GET_ETSYM_M1
int get_etsym_m1(c)
struct S_CUBE *c;
{
  return ((op16e[c->op].op1 == 0) ?et_sym[c->et][c->op] :
    ((op16e[c->op].op1 == OP_FR) ?
    et_sym[et_sym_FR[EP0][c->et]][c->op] :
    et_sym[et_sym_UF[EP1][c->et]][c->op]));
}
#endif

#if USE_GET_ETSYM_M2
int get_etsym_m2(c)
struct S_CUBE *c;
{
  return ((op16e[c->op].op1 == 0) ? et_sym[c->et][c->op] :
    ((op16e[c->op].op1 == OP_FR) ?
    et_sym[et_sym_FR[EP0][c->et]][c->op] :
    et_sym[et_sym_FR[EP1][c->et]][c->op]));
}
#endif

char last_digit[5][4]={0,0,0,0, 0,0,0,0, 0,1,0,0, 0,2,1,0, 2,1,0,3};
int exp1[10][15];
int fac[15];

void init_conv()
{
  int i, j;

  for (i=2; i <= 4; i++)
    {
      exp1[i][1]=i;

      for (j=2; j <= 12; j++)
	exp1[i][j] = exp1[i][j-1]*i;
    }

  for (fac[2]=2, i=3; i <= 12; i++)
    fac[i] = i*fac[i-1];
}

void int_to_str(n, s, len, base)
     char *s;
     int n, len, base;
{
  int i, j;

  for (i=0, j=exp1[base][len-1]; i < len; n%=j, j/=base, i++)
    s[i] = (n/j);
}

void int_to_strp(n, s, len, base)
     char *s;
     int n, len, base;
{
  int i, j;

  for (i=0, j=exp1[base][len-1]; i < len; n%=j, j/=base, i++)
    s[i] = (n/j);

  for (i=j=0; i < len; i++)
    j += s[i];

  s[len] = last_digit[base][j%base];
}

int int_to_str_lim(n, s, len, base, lim)
     char *s;
     int n, len, base, lim;
{
  int i, j, ct[10];

  for (i=0; i < base; i++)
    ct[i] = 0;

  for (i=0, j=exp1[base][len-1]; i < len; n%=j, j/=base, i++)
    {
      s[i] = (n/j);
      ct[s[i]]++;

      if (ct[s[i]] > lim)
	return(0);
    }

  for (i=0; i < base; i++)
    if (ct[i] < lim)
      s[len] = i;

  return(1);
}

void int_to_perm(n, s, len)
     char *s;
     int n, len;
{
  int i, j, k;
  char tmp[15];

  for (i=0; i < len; i++)
    tmp[i] = i;

  len--;

  for (i=0, j=fac[len]; i < len; n%=j, j/=(len-i), i++)
    {
      s[i] = tmp[n/j];
      for (k=n/j; k < len-i; k++)
	tmp[k] = tmp[k+1];
    }

  s[len] = tmp[0];
}

int str_to_int(s, len, base)
     char *s;
     int len, base;
{
  int i, n;

  n = s[0];

  for (i=1; i < len; i++)
    {
      n *= base;
      n += s[i];
    }

  return(n);
}

int perm_to_int(s, len)
     char *s;
     int len;
{
  int i, j, k, q, v;

  for (q=0, i=len-2, j=1; i > 0; i--)
    {
      j *= len-(i+1);

      for (v=0, k=i+1; k < len; k++)
	if (s[i] > s[k])
	  v++;

      q +=j*v;
    }

  j *= len-1;
  q += s[0] *j;
  return q;
}

#define CHAR		1
#define SHORT		2
#define INT  		4

FILE *fp;
void populated();

void open_file(fname, mode)
     char *fname, *mode;
{
  if ((fp = fopen(fname,mode)) == NULL)
    {
      printf("Error opening file: <%s>\n", fname);
      exit(1);
    }
}

void make_text_file(fname, arr, n, type)
     char *fname, *arr;
     int n, type;
{
  int i, *ip;
  short *sp;

  sp = (short*)arr;
  ip = (int *)arr;
  open_file(fname, "w");

  for (i=0; i < n; i++)
    switch (type)
      {
      case CHAR : fprintf(fp, "%d\n", arr[i]); break;
      case SHORT: fprintf(fp, "%d\n",  sp[i]); break;
      case INT  : fprintf(fp, "%d\n",  ip[i]); break;
      };
  fclose(fp);
}

void load_text_file(fname, arr, n, type)
     char *fname, *arr;
     int n, type;
{
  char s[30];
  short *sp;
  int i, *ip;

  sp = (short*)arr;
  ip = (int *)arr;
  open_file(fname, "r");

  for (i=0; i < n; i++)
    {
      if (fgets(s, 10, fp) == NULL)
	{
	  printf("Error loading file: %s\n", fname);
	  exit(1);
	}

      switch (type)
	{
	case CHAR : arr[i]= atoi(s); break;
	case SHORT: sp[i] = atoi(s); break;
	case INT  : ip[i] = atoi(s); break;
	};
    }

  fclose(fp);
  sprintf(s, "%.*s", strlen(fname)-8, &fname[4]);
  populated(s);
}

void make_bin_file(char *fname, char *arr, long n, int type)
{
  long int total=0;

  n *= type;
  open_file(fname, "w");
  total = fwrite(arr, 1, n, fp);
  fclose(fp);

  if (total != n)
    {
      printf("Error Writing File: <%s>\n", fname);
      printf("  Bytes Written: %d\n", total);
      printf("  Bytes Expected: %u\n", n);
      exit(1);
    }
}

long load_bin_file(char *fname, char *arr, long n, int type)
{
  char s[30];
  long total=0;

  n *= type;
  open_file(fname, "r");
  total = fread(arr, 1, n, fp);
  fclose(fp);

  if (total != n)
    {
      printf("Error Loading File: <%s>\n", fname);
      printf("  Bytes Expected: %ld\n", n);
      printf("  Bytes Read: %ld\n", total);
      exit(1);
    }

  sprintf(s, "%.*s", strlen(fname)-8, &fname[4]);
  populated(s);
  return(total);
}

unsigned short cp6c_sym[C_PERM][CUBE_SYM];

#if (CT_SYM_METHOD == 1)
int get_min_op_6c_m1(c)
struct S_CUBE *c;
{	
  char eprsym[3], eprtmp[3];
  int i, n, dif, ep, cp, ct, cp6c, cpsym, ctsym, cp6csym, min_op;
  int oplist[CUBE_SYM];
  long long min, sym;
  n = ept_min_ops[c->ops_idx][2];
  if (n == CUBE_SYM-1)
    for (i=0; i < n; i++)
      oplist[i] = i+1;
  else
    for (i=0; i < n; i++)
      oplist[i] = ept_min_ops[c->ops_idx][i+3];
  get_eprsym(eprtmp, c->ep, c->epr, c->op);
  ep = min_ep[ep_min[c->ep]];
  cp6c = cp6c_sym[c->cp6c][c->op];
  cp = cp_sym[c->cp][c->op];
  ct = ct_sym[c->cp][c->ct][c->op];
  min = (long long) ((cp*C_TWIST + ct)*C_PRMr +
		     cp6c_cpr[cp6c])*E_PRMr + EPR(eprtmp);
  for (i=dif=0; i < n; i++)
    {
      cp6csym = cp6c_sym[cp6c][oplist[i]];
      get_eprsym(eprsym, ep, eprtmp, oplist[i]);
      cpsym = cp_sym[cp][oplist[i]];
      ctsym = ct_sym[cp][ct][oplist[i]];
      sym = (long long) ((CPSYM*C_TWIST + CTSYM)*C_PRMr +
			 cp6c_cpr[cp6csym])*E_PRMr + EPR(eprsym);
      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
   c->op = op_op[c->op][min_op];
}
#endif

#if (CT_SYM_METHOD == 2)
int get_min_op_6c_m2(c)
struct S_CUBE *c;
{	
  char eprsym[3], eprtmp[3];
  int i, n, dif, min_op, cp6csym, ep, cp6c;
  int oplist[CUBE_SYM];
  struct s_cpt *csym;
  long long min, sym;
  struct s_min cpt;
  n = ept_min_ops[c->ops_idx][2];
  if (n == CUBE_SYM-1)
    for (i=0; i < n; i++)
      oplist[i] = i+1;
  else
    for (i=0; i < n; i++)
      oplist[i] = ept_min_ops[c->ops_idx][i+3];
  get_eprsym(eprtmp, c->ep, c->epr, c->op);
  ep = min_ep[ep_min[c->ep]];
  cp6c = cp6c_sym[c->cp6c][c->op];
  cpt.op = op_op[c->cpt.op][c->op];
  cpt.min = c->cpt.min;
  csym = &cpt_sym[cpt.min][cpt.op];
  min = (long long) ((CPSYM*C_TWIST + CTSYM)*C_PRMr +
		     cp6c_cpr[cp6c])*E_PRMr + EPR(eprtmp);
  for (i=dif=0; i < n; i++)
    {
      cp6csym = cp6c_sym[cp6c][oplist[i]];
      get_eprsym(eprsym, ep, eprtmp, oplist[i]);
      csym = &cpt_sym[cpt.min][op_op[cpt.op][oplist[i]]];
      sym = (long long) ((CPSYM*C_TWIST + CTSYM)*C_PRMr +
			 cp6c_cpr[cp6csym])*E_PRMr + EPR(eprsym);
      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
   c->op = op_op[c->op][min_op];
}
#endif

int cubestr_to_ep(char *s) {
  char eps[12];
  int R = s[28];
  int U = s[4];
  int F = s[25];
  for (int i=0; i < 12; i++) {
    int x = s[edg_idx[i][0]];
    int y = s[edg_idx[i][1]];
    if (x == U || (x == F && y == R))
      eps[i] = (x == F) ? 0 : (y == R) ? 2 : 1;
    else
      eps[i] = (x == F) ? 1 : (y == U) ? 2 : 0;
  }
  return b3_ep[str_to_int(eps,11,3)];
}

int cubestr_to_et(char *s) {
  char ets[12];
  int R = s[28];
  int U = s[4];
  int F = s[25];
  for (int i=0; i < 12; i++) {
    int x = s[edg_idx[i][0]];
    int y = s[edg_idx[i][1]];
    ets[i] = (x == U || (x == F && y == R)) ? 0 : 1;
  }
  return str_to_int(ets,11,2);
}

int cubestr_to_cp(char *s) {	
  char cps[8];
  char U = s[4];
  char F = s[25];
  for (int i=0; i < 8; i++) {
    int x = s[cnr_idx[i][0]];
    int y = s[cnr_idx[i][1]];
    int z = s[cnr_idx[i][2]];
    if (x == U)
      cps[i] = (y == F) ? 0 : 1;
    else if (y == U)
      cps[i] = (z == F) ? 0 : 1;
    else
      cps[i] = (x == F) ? 0 : 1;
  }
  return b2_cp[str_to_int(cps, 7, 2)];
}

int cubestr_to_ct(char *s) {	
  char cts[8];
  char U = s[4];
  for (int i=0; i < 8; i++) {
    int x = s[cnr_idx[i][0]];
    int y = s[cnr_idx[i][1]];
    if (x == U)
      cts[i] = 0;
    else if (y == U)
       cts[i] = 1;
    else
       cts[i] = 2;
  }
  return(str_to_int(cts, 7, 3));
}

void cubestr_to_cpt(char *s, struct s_cpt *cpt) {
  char cps[8];
  char cts[8];
  char U = s[4];
  char F = s[25];
  for (int i=0; i < 8; i++) {
    int x = s[cnr_idx[i][0]];
    int y = s[cnr_idx[i][1]];
    int z = s[cnr_idx[i][2]];
    if (x == U) {
      cts[i] = 0;
      cps[i] = (y == F) ? 0 : 1;
    }
    else if (y == U) {
      cts[i] = 1;
      cps[i] = (z == F) ? 0 : 1;
    }
    else {
      cts[i] = 2;
      cps[i] = (x == F) ? 0 : 1;
    }
  }
  cpt->cp = b2_cp[str_to_int(cps, 7, 2)];;
  cpt->ct = str_to_int(cts, 7, 3);
}

void assign_centers_3c(char *cubestr) {
  cubestr[28] = 0;
  cubestr[25] = 1;
  cubestr[4]  = 2;
  cubestr[22] = 0;
  cubestr[31] = 1;
  cubestr[49] = 2;
}

void set_colors_3c(r, f, u)
  char r, f, u;
{
  cnr2[0][0] = u;
  cnr2[0][1] = f;
  cnr2[0][2] = r;
  cnr2[1][0] = u;
  cnr2[1][1] = r;
  cnr2[1][2] = f;

  edg2[0][0] = f;
  edg2[0][1] = r;
  edg2[1][0] = u;
  edg2[1][1] = f;
  edg2[2][0] = u;
  edg2[2][1] = r;
}

#if USE_ET_FR
void populate_et_fr() {
  for (int i=0; i < SLICE_PRM; i++)
    for (int j=0; j < E_TWIST; j+=16) {
      int n = et_sym_FR[i][j];
      et_fr_ix[i][j/16] = n;
      if (et_fr[n][1] == 0)
        for (int k=0; k < 16; k++)
          et_fr[n][k] = et_sym_FR[i][j+k];
    }
}
#endif
