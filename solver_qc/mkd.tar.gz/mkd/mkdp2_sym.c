/* Author: Michael Feather

This version of mkdp2 uses 6C symmetry with chk_dup().

---------------------------------------------------------------------------
          Unique     Total
---------------------------------------------------------------------------
    0          1         1
    1          1         6
    2          2        27
    3          5       120
    4         18       519
    5         62      2124
    6        214      8188
    7        693     27636
    8       1871     78644
    9       4114    175497
   10       5702    248288
   11       5614    252210
   12      14444    685188
   13      30935   1480040
   14      18715    883908
   15       3088    137200
   Total   85479   3979596

   13824*576/2 = 3981312 - 3979596 = 1716 cubes not reached (depth 16)
*/

#include "rc.h"
#include "func.h"
#include "dist.h"

#define SYM_FIRST_MOVE  1
#define USE_CHK_DUP     1

unsigned char dist[C_PRMr][E_PRMr];
unsigned short cp6c_sym[C_PERM][CUBE_SYM];

int count, depth, max_depth, seq[20];
int cpr_cp6c[C_PRMr];

void populate_dist_array2();
void apply_dist_sym();
void populate_cpr_cp6c();
void show_counts();
int  get_min_op_6c_m1();
int  get_min_op_6c_m2();

int main()
{
  char fname[100];
  init();
  snprintf(fname, DAT_FNAME_LEN, "dat/P2_0004H_%02d%c.dat",
	   P2_GEN_DEPTH, metric);
  printf("Generating: %s\n", fname+4);
  populate_dist_array();
  printf("Writing: %s\n", fname+4);
  make_bin_file(fname, distp2, sizeof(distp2), CHAR);
  exit(0);
}

void populate_dist_array()
{
  int i, j, n;
  struct S_CUBE c;

  c.ep = 0;
  c.et = c.cp = c.ct = 0;
  c.cpt.min = c.cpt.op = 0;
  c.epi = &ep_info[0];
  c.op = 0;
  c.epr[0] = c.epr[1] = c.epr[2] = 0;
  c.cp6c = 0;
  c.cpt.min = c.cpt.op = 0;

  dist[0][0] = 1;

  printf("Generating to depth: %d\n", P2_GEN_DEPTH);

  for (depth=1; depth <= P2_GEN_DEPTH; depth++)
    {
      cfg_idx = 0;
      count = 0;
      if (SYM_FIRST_MOVE)
        search(&c, 1, mvlist2);
      else
        search(&c, 1, mvlist1);
      printf("%5d %10d\n", depth, count);
      fflush(stdout);
    }

  populate_dist_array2();

  n = P2_GEN_DEPTH+1;

  if (P2_GEN_DEPTH < 15)
    for (i=count=0; i < C_PRMr; i++)
      for (j=0; j < E_PRMr; j++)
        if (dist[i][j] == 0)
	  {
	    dist[i][j] = n;
	    count++;
	  }

  dist[0][0] = 0;
  show_counts();

  for (i=0; i < C_PRMr; i++)
    for (j=0; j < E_PRMr; j+=2)
      distp2[i][j/2] = (dist[i][j+1]<<4) + dist[i][j];
}

void search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  int i, mv, dst, tmp, cpsym, ctsym, EPRsym;
  int cp6csym, cprsym;
  struct s_cpt *csym;
  struct S_CUBE m;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      EP_MOV_CODE
      ET_MOV_CODE
      EPR_MOV_CODE
      CORNER_MOV_CODE
      CP6C_MOV_CODE
      EPI_CODE
      OP_CODE
      ET_SYM_CODE

      #if CT_SYM_METHOD == 1
      EPT_MIN_OP_CODE(get_min_op_6c_m1)
      #elif CT_SYM_METHOD == 2
      EPT_MIN_OP_CODE(get_min_op_6c_m2)
      #endif

      CORNER_SYM_CODE;

      if (n == depth)
	{
	  if (m.ep == 0 && m.et == 0 && CORNER_3C_SOLVED)
	    {
              cp6csym = cp6c_sym[m.cp6c][m.op];
	      cprsym = cp6c_cpr[cp6csym];
              EPR_SYM_CODE_NEW

	        if (dist[cprsym][EPRsym] == 0)
		  {
		    dist[cprsym][EPRsym] = depth;
		    count++;
		  }
	    }
	}
      else
	{
	  #if USE_CHK_DUP
	  if (n <= 5)
	    {
              cp6csym = cp6c_sym[m.cp6c][m.op];
              EPR_SYM_CODE_NEW
	      if (chk_dup_6c(EPMIN, m.etsym, EPRsym, cp6csym, CTSYM, n))
		continue;
	    }
          #endif

	  tmp = dist1[EPMIN][CPSYM][CTSYM>>(D1_RS+1)];
	  dst = n + (((CTSYM>>D1_RS)&1) ? tmp>>4 : tmp&0xF);
	
	  if (dst > depth)
	    continue;
	
	  tmp = dist2[EPMIN][CPSYM][m.etsym>>(D2_RS+1)];
	  dst = n + (((m.etsym>>D2_RS)&1) ? tmp>>4: tmp&0xF);
	
	  if (dst > depth)
	    continue;

          if (m.ep == 0 && m.et == 0 && CORNER_3C_SOLVED)
          {
              cp6csym = cp6c_sym[m.cp6c][m.op];
	      cprsym = cp6c_cpr[cp6csym];
              EPR_SYM_CODE_NEW

              dst = dist[cprsym][EPRsym];

              if (dst < n)
                continue;

              if (dst != n)
                printf("3C cube not pruned, dist=%d  n=%d  depth=%d\n",
			dst, n, depth);

	      if (cprsym == 0 && EPRsym == 0)
                 printf("home cube not pruned\n");
          }

	  seq[n] = mv;
	  search(&m, n+1, seq_gen[mv]);
	}
    }
}

void init()
{
  init3();
  load_bin_file("dat/cp6c_sym.dat", cp6c_sym, C_PERM*CUBE_SYM, SHORT);
  seq[0] = NIL;
  populate_cpr_cp6c();
  load_dist_files();
}

int load_dist_files()
{
  char fname [50];

  if (USE_DIST1 == 0 || USE_DIST2 == 0)
    {
      printf("USE_DIST1 or USE_DIST2 is not set\n");
      exit(0);
    }

  snprintf(fname, DAT_FNAME_LEN, "dat/D1_%04dH_%02d%c.dat",
	   DIST1_SIZE, D1_GEN_DEPTH, metric);

  load_dist_file(fname, dist1, sizeof(dist1));

  snprintf(fname, DAT_FNAME_LEN, "dat/D2_%04dH_%02d%c.dat",
	  DIST2_SIZE, D2_GEN_DEPTH, metric);

  load_dist_file(fname, dist2, sizeof(dist2));

  return(0);
}

void populate_dist_array2()
{
  int i, j, a, b, c;
  char epr[3];

  for (i=0; i < C_PRMr; i++)
    for (a=0; a < 24; a++)
      {
	epr[0] = a;
	for (b=0; b < 24; b++)
	  {
	    epr[1] = b;
	    for (c=0; c < 24; c++)
	      {
		epr[2] = c;
		j = EPR(epr);
		
		if (dist[i][j])
		  apply_dist_sym(i, epr, dist[i][j]);
	      }
	  }
      }
}

void apply_dist_sym(cpr, epr, n)
     int cpr, n;
     char *epr;
{
  int op, cprsym, EPRsym;
  char eprsym[3];

  for (op=0; op < CUBE_SYM; op++)
  {
    cprsym = cp6c_cpr[cp6c_sym[cpr_cp6c[cpr]][op]];
    get_eprsym(eprsym, 0, epr, op);
    EPRsym = EPR(eprsym);

    if (dist[cprsym][EPRsym] == 0)
      dist[cprsym][EPRsym] = n;
  }
}

void populate_cpr_cp6c()
{
  int i, j;
  for (i=j=0; i < 40320; i++)
    if (cp6c_cp3c[i] == 0)
      cpr_cp6c[j++] = i;
}

void show_counts()
{
  int i, j, cnt[30];

  for (i=0; i < 30; i++)
    cnt[i] = 0;

  for (i=0; i < C_PRMr; i++)
    for (j=0; j < E_PRMr; j++)
      cnt[dist[i][j]]++;

  for (i=0; i < 30; i++)
    if (cnt[i] != 0)
      printf("%2d %10d\n", i, cnt[i]);
}
