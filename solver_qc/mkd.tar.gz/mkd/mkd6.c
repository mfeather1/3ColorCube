/* Author: Michael Feather 

  Moves    Configs
    1            8
    2           45
    3          282
    4         2148
    5        18057
    6       168456
    7      1536596
    8      6975010
    9      2109459
   10          306
*/

#include "rc.h"
#include "func.h"

char depth;
unsigned char dist[MIN_EP][E_PRMr];
int bs, brkpt, count, ep_bs, epr_bs[3];
int seq[20];
jmp_buf env;

int main()
{
  char fname[DAT_FNAME_LEN];

  init();
  snprintf(fname, DAT_FNAME_LEN, "dat/D6_0005H_10%c.dat", metric);
  printf("Generating: %s\n", fname+4);
  populate_dist_array();
  printf("Writing: %s\n", fname+4);
  make_bin_file(fname, dist, sizeof(dist)/2, CHAR);
  exit(0);
}

void populate_dist_array()
{
  int i;
  struct S_CUBE c;

  brkpt = 6;

  c.epi = &ep_info[0];
  c.ep = 0;
  c.epr[0] = c.epr[1] = c.epr[2] = 0; 

  dist[0][0] = 1;
  bs = FALSE;
  printf("  Moves    Configs\n");

  for (depth=1; depth <= brkpt; depth++)
    {
      count = 0;
      search(&c, 1, mvlist2);
      show_dist_count_line(depth, count);
    }

  bs = TRUE;

  for (i=0; i < 3; i++)
    {
      count=0;
      backsearch(1);
      show_dist_count_line(brkpt+1, count);
      brkpt++;
    }

  backsearch(4);
  dist[0][0] = 0;
  show_dist_counts(dist, sizeof(dist), brkpt+1);
  mk_hexd_arr(dist, sizeof(dist));
}

void search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  int i, mv, EPRsym;
  struct S_CUBE m;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      EP_MOV_CODE
      EPR_MOV_CODE
      EPI_CODE

      m.op = m.epi->op;

      EPR_SYM_CODE_NEW

      if (n == depth)
	{
	  if (bs == FALSE)
	    {
	      if (dist[EPMIN][EPRsym] == 0)
		{
		  dist[EPMIN][EPRsym] = depth;
		  count++;
		}
	    }
	  else
	    {
	      if (dist[EPMIN][EPRsym] == brkpt)
		{
		  dist[ep_bs][EPR(epr_bs)] = brkpt+depth;
		  count++;
		  longjmp(env,1);
		}
	    }
	}
      else
	{
	  seq[n] = mv;
	  search(&m, n+1, seq_gen[mv]);
	}
    }
}

void init()
{
  init3();
  seq[0] = NIL;
  populate_min_ep();
}

void backsearch(n)
int n;
{
  int i, x, y, z;
  struct S_CUBE c;

  for (i=0;  i < MIN_EP; i++)
    {
      ep_bs = i;
      c.ep = min_ep[i];
      c.epi = &ep_info[c.ep];

      for (x=0; x < 24; x++)
	{
	  c.epr[0] = x;
	  epr_bs[0] = x;

	  for (y=0; y < 24; y++)
	    {
	      c.epr[1] = y;
	      epr_bs[1] = y;

	      for (z=0; z < 24; z++)
		{
		  c.epr[2] = z;
		  epr_bs[2] = z;

		  if (dist[ep_bs][EPR(epr_bs)] == 0)
		    {
		      if (setjmp(env) == 0)
			for (depth=1; depth <= n; depth++)
			  search(&c, 1, mvlist2);
		    }
		}
	    }
	}
    }
}
