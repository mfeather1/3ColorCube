// Author: Michael Feather
// This program makes the symmetry tables

#include <dirent.h>
#include <string.h>

#include "rc.h"
#include "sym.h"
#include "func.h"

char eps[12], ets[12], cps[8], cts[8];
char cubestr[FACELETS];
char map[CUBE_SYM][FACELETS];
char ept_min_op[N_EPT_MIN_OP][E_TWIST];
unsigned short ep_sym[E_PRM][CUBE_SYM];
unsigned short cp6c_sym[C_PERM][CUBE_SYM];
short et_sym_FR[SLICE_PRM][E_TWIST];
short et_sym_UF[SLICE_PRM][E_TWIST];
struct s_cpt cpt_sym[MIN_CPT][CUBE_SYM];
int ept_op_idx[E_PRM];
int ept_op_row_compare();
int convert_cnr_6c();
int get_etsym1(), get_etsym2();

#if USE_CT_SYM
int tmp_sym_map[C_PRM_TW][CUBE_SYM];
#else
int tmp_sym_map[C_PERM][CUBE_SYM];
#endif

int main()
{
  print("Initializing\n");
  init();

  print("Generating: cp6c_min.dat\n");
  print("Generating: cp6c_min_op.dat\n");
  populate_cp6c_sym();
  make_text_file("dat/cp6c_min.dat", cp6c_min, C_PERM, INT);
  make_text_file("dat/cp6c_min_op.dat", cp6c_min_op, C_PERM, CHAR);

  #if USE_CP6C_SYM
  print("Generating: cp6c_sym.dat\n");
  make_bin_file("dat/cp6c_sym.dat", cp6c_sym, C_PERM*CUBE_SYM, SHORT);
  #endif

  printf("Generating: inv_op.dat\n");
  printf("Generating: op_op.dat\n");
  printf("Generating: op_mv.dat\n");
  populate_op_tables();
  make_text_file("dat/inv_op.dat", inv_op, CUBE_SYM, CHAR);
  make_text_file("dat/op_op.dat", op_op, CUBE_SYM*CUBE_SYM, CHAR);
  make_text_file("dat/op_mv.dat", op_mv, CUBE_SYM*MOVES, CHAR);

  #if USE_EPR_SYM2
  print("Generating: epr_sym2.dat\n");
  print("Generating: epr_idx.dat\n");
  populate_epr_sym2();
  make_bin_file("dat/epr_sym2.dat", epr_sym2, N_EPR_SYM2*24, CHAR);
  make_bin_file("dat/epr_idx.dat", epr_idx, 3*CUBE_SYM*SLICE_PRM, CHAR);
  #else
  print("Generating: epr_sym.dat\n");
  populate_epr_sym();
  make_bin_file("dat/epr_sym.dat", epr_sym, 3*CUBE_SYM*SLICE_PRM*24, CHAR);
  #endif

  populate_et_sym_arr(et_sym_FR, OP_FR, 0);
  populate_et_sym_arr(et_sym_UF, OP_UF, 1);

  #if USE_ET_SYM_FR
  print("Generating: et_sym_fr.dat\n");
  make_bin_file("dat/et_sym_fr.dat", et_sym_FR, SLICE_PRM*E_TWIST, SHORT);
  #endif

  #if USE_ET_SYM_UF
  print("Generating: et_sym_uf.dat\n");
  make_bin_file("dat/et_sym_uf.dat", et_sym_UF, SLICE_PRM*E_TWIST, SHORT);
  #endif

  populate_et_sym();
  make_bin_file("dat/et_sym_m0.dat", et_sym, CUBE_SYM*E_TWIST, SHORT);

  update_et_sym();

  #if USE_ET_SYM
  if (ET_SYM_METHOD == 1) {
    print("Generating: et_sym_m1.dat\n");
    make_bin_file("dat/et_sym_m1.dat", et_sym, CUBE_SYM*E_TWIST, SHORT);
  }
  else {
    print("Generating: et_sym_m2.dat\n");
    make_bin_file("dat/et_sym_m2.dat", et_sym, CUBE_SYM*E_TWIST, SHORT);
  }
  #endif

  print("Generating: ep_min.dat\n");
  print("Generating: ep_min_op.dat\n");
  populate_ep_sym();
  make_text_file("dat/ep_min.dat", ep_min, E_PRM, INT);
  make_text_file("dat/ep_min_op.dat", ep_min_op, E_PRM, CHAR);

  #if USE_EP_SYM
  print("Generating: ep_sym.dat\n");
  make_bin_file("dat/ep_sym.dat", ep_sym, E_PRM*CUBE_SYM, SHORT);
  #endif

  print("Generating: ept_min_ops.dat\n");
  populate_ept_min_op();
  make_ept_min_ops();

  #if USE_EPT_MIN_OP
  print("Generating: ept_min_op.dat\n");
  print("Generating: ept_op_idx.dat\n");
  make_bin_file("dat/ept_min_op.dat", ept_min_op, N_EPT_MIN_OP*E_TWIST, CHAR);
  make_text_file("dat/ept_op_idx.dat", ept_op_idx, E_PRM, INT);
  #endif

  print("Generating: cpt_min.dat\n");
  print("Generating: cpt_min_op.dat\n");
  print("Generating: cpt_sym.dat\n");
  populate_cpt_sym();
  make_text_file("dat/cpt_min.dat", cpt_min, C_PRM_TW, SHORT);
  make_text_file("dat/cpt_min_op.dat", cpt_min_op, C_PRM_TW, CHAR);
  make_bin_file("dat/cpt_sym.dat", cpt_sym, MIN_CPT*CUBE_SYM, INT);

  #if USE_CP_SYM
  print("Generating: cp_sym.dat\n");
  populate_cp_sym();
  make_bin_file("dat/cp_sym.dat", cp_sym, C_PRM*CUBE_SYM, CHAR);
  #endif

  #if USE_CT_SYM
  print("Generating: ct_sym.dat\n");
  populate_ct_sym();
  make_bin_file("dat/ct_sym.dat", ct_sym, C_PRM*C_TWIST*CUBE_SYM, SHORT);
  #endif

  exit(0);
}

void populate_cp6c_sym()
{
  int i, j;
  char tempstr[FACELETS];

  assign_centers_6c();

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, cps, 8);
      set_colors_6c(0,1,2,3,4,5,6);
      make_cubestr_cnr(cnr);
      tmp_sym_map[i][0] = i;

      for (j=1; j < CUBE_SYM; j++)
	{
	  sym_op(tempstr, cubestr, map[j]);
	  tmp_sym_map[i][j] = convert_cnr_6c(tempstr, cps, cts);
	}
    }

  for (i=0; i < C_PERM; i++)
    for (j=0; j < CUBE_SYM; j++)
      cp6c_sym[i][j] = tmp_sym_map[i][j];

  populate_arr_min(cp6c_min, cp6c_min_op, C_PERM);

  populated("cp6c_sym");
  populated("cp6c_min");
  populated("cp6c_min_op");
}

void populate_ep_sym() {
  char tempstr[FACELETS];
  assign_centers_3c(cubestr);
  for (int ep=0; ep < E_PRM; ep++) {
    int_to_strp(ep_b3[ep], eps, 11, 3);
    make_cubestr_edg(edg2);
    tmp_sym_map[ep][0] = ep;
    for (int op=1; op < CUBE_SYM; op++) {
      sym_op(tempstr, cubestr, map[op]);
      tmp_sym_map[ep][op] = cubestr_to_ep(tempstr);
    }
  }
  for (int ep=0; ep < E_PRM; ep++)
    for (int op=0; op < CUBE_SYM; op++)
      ep_sym[ep][op] = tmp_sym_map[ep][op];
  populate_arr_min(ep_min, ep_min_op, E_PRM);
  populated("ep_sym");
  populated("ep_min");
  populated("ep_min_op");
  populate_min_ep();
}

void populate_arr_min(arr_min, arr_min_op, rows)
     int *arr_min, rows;
     char *arr_min_op;
{	
  int i, j, k, min, op;
  int *row, tmp[C_PRM_TW];

  for (i=0; i < rows; i++)
    tmp[i] = NIL;

  row = tmp_sym_map[0];

  for (i=k=0; i < rows; i++)
    {
      min = row[0];
      for (j=op=0; j < CUBE_SYM; j++)
	{
	  if (row[j] < min)
	    {
	      min = row[j];
	      op = j;
	    }
	}

      if (tmp[min] == NIL)
	tmp[min] = k++;

      arr_min[i] = tmp[min];
      arr_min_op[i] = op;
      row += CUBE_SYM;
    }
}

void make_cubestr_edg(edg)
     char edg[12][2];
{
  int i, j;

  for  (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      cubestr[edg_idx[i][j]] = edg[eps[i]] [(ets[i]+j)&1];
}

void make_cubestr_cnr(cnr)
     char cnr[8][3];
{
  int i, j;

  for (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
	cubestr[cnr_idx[i][j]] = cnr[cps[i]] [(untwc[cts[i]]+j)%3];
}

void init()
{
  make_dat_dir();
  init2();
  set_colors_3c(0, 1, 2);
  init_map(map, sym_op_FR, sym_op_UR, reflect);
}

void make_dat_dir()
{
  DIR *dp;

  dp = opendir("dat");

  if (dp != NULL)
    closedir(dp);
  else
    if (mkdir("dat", 0755) != 0)
      {
	printf("ERROR: could not create subdirectory: dat\n");
	perror("");
	exit(1);
      }
}

void assign_centers_6c()
{
  cubestr[28] = 0;
  cubestr[25] = 1;
  cubestr[4]  = 2;
  cubestr[22] = 3;
  cubestr[31] = 4;
  cubestr[49] = 5;
}

void print(s)
     char *s;
{	
  printf("%s", s);
  fflush(stdout);
}

void make_ept_min_ops()
{
  int i, j, n;

  open_file("dat/ept_min_ops.dat", "w");

  for (i=0; i < N_EPT_MIN_OPS; i++)
    {
      fprintf(fp, "%5d ", ept_min_ops[i][0]);
      fprintf(fp, "%4d ", ept_min_ops[i][1]);
      n = ept_min_ops[i][2];
      fprintf(fp, "%2d ", n);

      if (n < 47)
	for (j=3; j < n+3; j++)
	  fprintf(fp, "%2d ", ept_min_ops[i][j]);

      fprintf(fp, "\n");
    }

 fclose(fp);
}

#if ! USE_CP6C_MOV
unsigned short cp6c_mov[C_PERM][MOVES];

void populate_cp6c_mov()
{
  int i, j, k;
  char s[8], tmp[8];

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=0; j < 8; j++)
	tmp[j] = s[j]/4;

      cp6c_cp3c[i] = b2_cp[str_to_int(tmp,7,2)];

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 8; k++)
	    tmp[k] = s[cmv[j][k]];
	  cp6c_mov[i][j] = perm_to_int(tmp, 8);
	}
    }
}
#endif

void populate_op_tables()
{
  unsigned short *mp;
  int i, j, k;

  dependency("cp6c_sym", "populate_op_tables");
  dependency("cp6c_min", "populate_op_tables");

  populate_cp6c_mov();

  mp = cp6c_sym[CP6C_OP_ROW];

  for (i=0; i < CUBE_SYM; i++)  	
    for (j=0; j < CUBE_SYM; j++)
      if (cp6c_sym[mp[i]][j] == mp[0])
	inv_op[i] = j;

  for (i=0; i < CUBE_SYM; i++)
    for (j=0; j < CUBE_SYM; j++)
      for (k=0; k < CUBE_SYM; k++)
	if (mp[i] == cp6c_sym[mp[j]][k])
	  op_op[j][k] = i;

  for (i=0; i < MOVES; i++)
    for (j=0; j < CUBE_SYM; j++)
      for (k=0; k < MOVES; k++)
	if (cp6c_min[cp6c_mov[mp[0]][i]] ==
	    cp6c_min[cp6c_mov[mp[j]][k]])
	  op_mv[j][k] = i;

  populated("inv_op");
  populated("op_op");
}

void populate_ept_op_idx()
{
  int i, j, k, m;

  dependency("ep_sym", "populate_ept_op_idx");
  dependency("ep_min", "populate_ept_op_idx");
  dependency("ep_min_op", "populate_ept_op_idx");

  for (i=1; i < E_PRM; i++)
      ept_op_idx[i] = NIL;

  for (i=k=1; i < E_PRM; i++)
    {
      m = min_ep[ep_min[i]];

      for (j=0; j < CUBE_SYM; j++)
	if ((ep_sym[i][j] == m) && (j != ep_min_op[i]))
	  {
	    ept_op_idx[i] = k++;
	    break;
	  }
    }
}

void populate_ept_min_op()
{
  int i, j, k, n, ep, et, ix, min, oplist[50];
  short tmp_idx[EP_MULTI_MIN_OP];
  static char ept_op_tmp[EP_MULTI_MIN_OP][E_TWIST];
  static char ept_op_sort[EP_MULTI_MIN_OP][E_TWIST];

  int (*get_etsym)() = (ET_SYM_METHOD == 1) ? get_etsym1 : get_etsym2;

  check_et_sym_dependencies("populate_ept_min_op");

  dependency("inv_op", "populate_ept_min_op");

  populate_ept_op_idx();

  for (i=ix=0; i < E_PRM; i++)
    {
      if (ep_min_op[i] != 0 || ept_op_idx[i] == NIL)
	continue;

      for (j=0; j < E_TWIST; j++)
	{
	  if (ept_op_tmp[ept_op_idx[i]][j] != 0)
	    continue;
	
	  ept_op_tmp[ept_op_idx[i]][j] = 0;
	  min = i*E_TWIST + j;
	
	  for (n=0, k=1; k < CUBE_SYM; k++)
	    {
	      ep = ep_sym[i][k];
	      et = get_etsym(i, j, k);
	      ept_op_tmp[ept_op_idx[ep]][et] = inv_op[k];

	      if (ep*E_TWIST + et == min)
		oplist[n++] = k;
	    }

	  if (n)
	    {
	      ept_min_ops[ix][0] = i;
	      ept_min_ops[ix][1] = j;
	      ept_min_ops[ix][2] = n;

	      if (n < 47)
		for (k=0; k < n; k++)
		  ept_min_ops[ix][k+3] = oplist[k];
	      ix++;
	    }
	}
    }

  populated("ept_min_ops");

  memcpy(ept_op_sort, ept_op_tmp, E_TWIST*EP_MULTI_MIN_OP);
  qsort(ept_op_sort, EP_MULTI_MIN_OP, E_TWIST, ept_op_row_compare);

  for (i=ix=1; i < EP_MULTI_MIN_OP; i++)
    if (ept_op_row_compare(ept_op_sort[i], ept_op_sort[ix-1]) != 0)
      memcpy(ept_op_sort[ix++], ept_op_sort[i], E_TWIST);

  for (i=0; i < EP_MULTI_MIN_OP; i++)
    {
      char *ptr = bsearch(ept_op_tmp[i], ept_op_sort, N_EPT_MIN_OP, E_TWIST,
                          ept_op_row_compare);
      tmp_idx[i] = (ptr - ept_op_sort[0]) / E_TWIST;
    }

  for (i=0; i < E_PRM; i++)
    if (ept_op_idx[i] != NIL)
      ept_op_idx[i] = tmp_idx[ept_op_idx[i]];

  memcpy(ept_min_op, ept_op_sort, N_EPT_MIN_OP*E_TWIST);
  populated("ept_min_op");
}

int ept_op_row_compare(a, b)
     char *a, *b;
{
  return(memcmp(a, b, E_TWIST));
}

void populate_cpt_sym() {
  char tempstr[FACELETS];
  struct s_cpt csym;
  assign_centers_3c(cubestr);
  for (int i=0; i < C_PRM_TW; i++) {
    cpt_min[i] = NIL;
    cpt_min_op[i] = 99;
  }
  for (int cp=0, min=0; cp < C_PRM; cp++) {
    int_to_strp(cp_b2[cp], cps, 7, 2);
    for (int ct=0; ct < C_TWIST; ct++) {
      int_to_strp(ct, cts, 7, 3);
      make_cubestr_cnr(cnr2);
      if (cpt_min[cp*C_TWIST+ct] == NIL) {
        for (int op=0; op < CUBE_SYM; op++) {
          sym_op(tempstr, cubestr, map[op]);
          cubestr_to_cpt(tempstr, &csym);
          cpt_sym[min][op] = csym;
          int yy = csym.cp*C_TWIST + csym.ct;
          cpt_min[yy] = min;
          char *minop = &cpt_min_op[yy];
          if (inv_op[op] < *minop)
	    *minop = inv_op[op];
        }
        min++;
      }
    }
  }
}

void populate_et_sym()
{
  int i, j;
  char tempstr[FACELETS];

  dependency("op_op", "populate_et_sym");

  init_op16e();
  assign_centers_3c(cubestr);
  int_to_strp(ep_b3[0], eps, 11, 3);

  for(i=0; i < E_TWIST;  i++)
    for (j=0; j < CUBE_SYM; j++)
      if (op16e[j].op1 == 0)
	  {
	    int_to_strp(i, ets, 11, 2);
	    make_cubestr_edg(edg2);
	    sym_op(tempstr, cubestr, map[j]);
	    et_sym[i][j] = cubestr_to_et(tempstr);
	  }

  populated("et_sym");
}

void populate_et_sym_arr(arr, op, slice)
     unsigned short arr[][E_TWIST];
     int op, slice;
{
  int i, j;
  char tempstr[FACELETS];

  assign_centers_3c(cubestr);

  for (i=0; i < SLICE_PRM; i++)
    {
      int_to_strp(ep_b3[slice_ep[i][slice]], eps, 11, 3);

      for (j=0; j < E_TWIST; j++)
	{
	  int_to_strp(j, ets, 11, 2);
	  make_cubestr_edg(edg2);
	  sym_op(tempstr, cubestr, map[op]);
	  arr[i][j] = cubestr_to_et(tempstr);
	}
    }

  if (op == OP_FR)
    populated("et_sym_fr");

  if (op == OP_UF)
    populated("et_sym_uf");
}

void update_et_sym()
{
  for (int op=0; op < CUBE_SYM; op++) {
    if (op16e[op].op1 != 0) {
      for (int et=0; et < E_TWIST; et++) {
        if (op16e[op].op1 == OP_FR || ET_SYM_METHOD == 1)
          et_sym[et][op] = et_sym[et][op16e[op].op2];
        else {
          int et_fr = et_sym_FR[0][et];
          int et_uf = et_sym_UF[0][et];
          et_sym[et_fr][op] = et_sym[et_uf][op16e[op].op2];
        }
      }
    }
  }
}

void check_et_sym_dependencies(s)
     char *s;
{
  dependency("et_sym", s);	
  dependency("et_sym_fr", s);
  dependency("et_sym_uf", s);
}

#if ! USE_EPR_SYM2
void populate_epr_sym()
{
  char init_str[12]={0,1,2,3,0,1,2,3,0,1,2,3};
  char epr[3], eps_3c[12],  eps_3r[12], tempstr[FACELETS];
  int i, j, op, slice, slice_sym;

  assign_centers_6c();

  for (slice=0; slice < 3; slice++)
    for (op=0; op < CUBE_SYM; op++)
      {
	slice_sym = slice_map[op][slice];
	
	for (i=0; i < SLICE_PRM; i++)
	  {
	    int_to_strp(ep_b3[slice_ep[i][slice]], eps_3c, 11, 3);
	    memcpy(eps_3r, init_str, 12);
	
	    for (j=0; j < 24; j++)
	      {
		int_to_perm(j, &eps_3r[slice*4], 4);
		mk_eps_6c(eps, eps_3c, eps_3r);
		set_colors_6c(0,1,2,3,4,5);
		make_cubestr_edg(edg);
		sym_op(tempstr, cubestr, map[op]);
		convert_edg_6c(tempstr, eps, ets);
		ep6c_epr(eps, epr);
		epr_sym[op][i][j][slice] = epr[slice_sym];
	      }
	  }
      }
}
#endif

#if USE_EPR_SYM2
void populate_epr_sym2()
{
  char init_str[12]={0,1,2,3,0,1,2,3,0,1,2,3};
  char s[24], epr[3], eps_3c[12], eps_3r[12], tempstr[FACELETS];
  short tmp_idx[E_PRMr];
  int i, j, ix, op, key, slice, slice_sym;

  assign_centers_6c();

  for (i=0; i < E_PRMr; i++)
    tmp_idx[i] = NIL;

  for (ix=slice=0; slice < 3; slice++)
    for (op=0; op < CUBE_SYM; op++)
      {
	slice_sym = slice_map[op][slice];

	for (i=0; i < SLICE_PRM; i++)
	  {
	    int_to_strp(ep_b3[slice_ep[i][slice]], eps_3c, 11, 3);
	    memcpy(eps_3r, init_str, 12);
	
	    for (j=0; j < 24; j++)
	      {
		int_to_perm(j, &eps_3r[slice*4], 4);
		mk_eps_6c(eps, eps_3c, eps_3r);
		set_colors_6c(0,1,2,3,4,5);
		make_cubestr_edg(edg);
		sym_op(tempstr, cubestr, map[op]);
		convert_edg_6c(tempstr, eps, ets);
		ep6c_epr(eps, epr);
		s[j] = epr[slice_sym];

		if (j == 2)
		  {
		    key = (s[0]*24 + s[1])*24 + s[2];

		    if (tmp_idx[key] == NIL)
		      {
			tmp_idx[key] = ix++;
			epr_idx[op][i][slice] = tmp_idx[key];
		      }
		    else
		      {
			epr_idx[op][i][slice] = tmp_idx[key];
			break;
		      }
		  }
	      }

	    if (j > 2)
	      memcpy(epr_sym2[tmp_idx[key]], s, 24);
	  }
      }
}
#endif

#if USE_CP_SYM
void populate_cp_sym() {
  char tempstr[FACELETS];
  assign_centers_3c(cubestr);
  for (int cp=0; cp < C_PRM; cp++) {
    int_to_strp(cp_b2[cp], cps, 7, 2);
    make_cubestr_cnr(cnr2);
    cp_sym[cp][0] = cp;
    for (int op=1; op < CUBE_SYM; op++) {
      sym_op(tempstr, cubestr, map[op]);
      cp_sym[cp][op] = cubestr_to_cp(tempstr);
    }
  }
  populated("cp_sym");
}
#endif

#if USE_CT_SYM
void populate_ct_sym() {
  char tempstr[FACELETS];
  assign_centers_3c(cubestr);
  for (int cp=0; cp < C_PRM; cp++) {
    int_to_strp(cp_b2[cp], cps, 7, 2);
    for (int ct=0; ct < C_TWIST; ct++) {
      int_to_strp(ct, cts, 7, 3);
      make_cubestr_cnr(cnr2);
      ct_sym[cp][ct][0] = ct;
      for (int op=1; op < CUBE_SYM; op++) {
        sym_op(tempstr, cubestr, map[op]);
        ct_sym[cp][ct][op] = cubestr_to_ct(tempstr);
      }
    }
  }
  populated("ct_sym");
}
#endif

int get_etsym1(ep, et, op)
     int ep, et, op;
{
  return ((op16e[op].op1 == 0) ? et_sym[et][op] :
    ((op16e[op].op1 == OP_FR) ?
    et_sym[et_sym_FR[ep_slice[ep][0]][et]][op] :
    et_sym[et_sym_UF[ep_slice[ep][1]][et]][op]));
}

int get_etsym2(ep, et, op)
     int ep, et, op;
{
  return ((op16e[op].op1 == 0) ? et_sym[et][op] :
    ((op16e[op].op1 == OP_FR) ?
    et_sym[et_sym_FR[ep_slice[ep][0]][et]][op] :
    et_sym[et_sym_FR[ep_slice[ep][1]][et]][op]));
}

