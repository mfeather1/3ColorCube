/* Author: Michael Feather
   This program makes Dists 1-4 for the solver.

  Depth        Dist1        Dist2        Dist3
  -----  -----------  -----------  -----------
    1              1            1            1
    2              3            3            3
    3             23           23           23
    4            241          237          230
    5           2948         2888         2823
    6          36359        35002        35462
    7         433044       401664       444312
    8        4641716      4183059      5449213
    9       33429131     30828052     62907892
   10       69728531     62279903    584924996
   11       11305961      5810832   2064988841
  Array    119716380    112107520   3502559232

                     Dist 4
  ----------------------------------------------
  Depth  913B  1827Q  1827B  3653Q  3653B  7307Q
  -----  -----------  ------------  ------------
    1              1             1             1
    2              3             3             3
    3             23            23            23
    4            241           241           241
    5           2980          2983          2983
    6          37867         37939         37968
    7         480605        482648        483875
    8        6044379       6106969       6146203
    9       73314231      75498733      76885350
   10      756671390     841398667     900319142
   11     3882242180    5797303651    7676423034
  Array   7661848320   15323696640   30647393280

  Unadjusted percentages:
   9          .00956        .00492        .00250
  10          .09875        .05490        .02937
  11          .50669        .37832        .25047

  ----------------------------------------------

      Dist4      ET bits      Array
  -------------  -------  ------------
    913B  1827Q     6       7661848320  70*2187*782*2^6
   1827B  3653Q     7      15323696640
   3653B  7307Q     8      30647393280
   7307B 14614Q     9      61294786560
  14614B 29228Q    10     122589573120
  29228B 58455Q    11     245179146240  70*2187*782*2^11
*/

#include "rc.h"
#include "dist.h"
#include "func.h"

#define SYM_FIRST_MOVE  1    // 0=all first moves, 1=sym first moves
#define USE_CHK_DUP     TRUE

#define SHOW_DEFINES    FALSE
#define SHOW_METHODS    FALSE

char use_d1, use_d2, use_d3, use_d4;
int depth, max_depth, quad_depth;
int seq[20];
long count[5];

int main()
{
  init();
  populate_dist_arrays();
  exit(0);
}

void populate_dist_arrays()
{
  int i;
  struct S_CUBE c;

  c.ep = 0;
  c.et = c.cp = c.ct = 0;
  c.cpt.min = c.cpt.op = 0;
  c.epi = &ep_info[0];
  c.op = 0;

  for (depth=1; depth <= max_depth; depth++)
    {
      cfg_idx = 0;
      count[1] = count[2] = count[3] = count[4] = 0;
      quad_depth = (depth <= max_depth-2) ? 1 : depth-(max_depth-3);

      #if SYM_FIRST_MOVE
      search(&c, 1, mvlist1);
      #else
      search(&c, 1, mvlist2);
      #endif

      show_line(depth);
      fflush(stdout);

      for (i=0; i <= 4; i++)
	if (use_dist[i])
	  if (depth == dist_depth[i])
	    {
	      update_dist(i);
	      write_dist_file(i);
	      update_use_dist(i);
	    }
    }
}

void search(c, n, mvlist)
     struct S_CUBE *c;
     int  n, *mvlist;
{
  int i, mv, tmp;
  int rs, cpsym, ctsym, dist;
  struct S_CUBE m;
  struct s_cpt *csym;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      APPLY_MOVE_3C;  // use macexp to view code

      if (n == depth)
	{
	  if (use_d1)
	    {
	      rs = CTSYM>>D1_RS;
	      tmp = dist1[EPMIN][CPSYM][rs>>1];
	      dist = ((rs&1) ? tmp>>4 : tmp&0xF);

	      if (dist == 0)
		{
		  dist1[EPMIN][CPSYM][rs>>1] |= ((rs&1)?n<<4:n);
		  count[1]++;
		}
	    }

	  if (use_d2)
	    {
	      rs = m.etsym>>D2_RS;
	      tmp = dist2[EPMIN][CPSYM][rs>>1];
	      dist = ((rs&1) ? tmp>>4 : tmp&0xF);

	      if (dist == 0)
		{
		  dist2[EPMIN][CPSYM][rs>>1] |= ((rs&1)?n<<4:n);
		  count[2]++;
		}
	    }
	
	  if (use_d3)
	    {
	      rs = m.etsym>>D3_RS;

	      if (DIST3_TYPE == 0)
		{
		  tmp = 1<<(rs&7);
		  dist = dist3[EPMIN][CTSYM][rs>>3] & tmp;

		  if (dist == 0)
		    {
		      dist3[EPMIN][CTSYM][rs>>3] |= tmp;
		      count[3]++;
		    }
		}

	      if (DIST3_TYPE == 1)
		{
		  dist = (dist3[EPMIN][CTSYM][rs>>2]>>((rs&3)<<1))&3;

		  if (dist == 0)
		    {
		      dist3[EPMIN][CTSYM][rs>>2] |=
			quad_depth<<((rs&3)<<1);
		      count[3]++;
		    }
		}

	      if (DIST3_TYPE == 2)
		{
		  tmp = dist3[EPMIN][CTSYM][rs>>1];
	          dist = ((rs&1) ? tmp>>4 : tmp&0xF);

		  if (dist == 0)
		    {
		      dist3[EPMIN][CTSYM][rs>>1] |= ((rs&1)?n<<4:n);
		      count[3]++;
		    }
		}
	    }

	  if (use_d4)
	    {
	      int cptsym = CPSYM*C_TWIST + CTSYM;
	      rs = m.etsym>>D4_RS;

	      if (DIST4_TYPE == 0)
		{
		  tmp = 1<<(rs&7);
		  dist = dist4[cptsym][EPMIN][rs>>3] & tmp;

		  if (dist == 0)
		    {
		      dist4[cptsym][EPMIN][rs>>3] |= tmp;
		      count[4]++;
		    }
		}

	      if (DIST4_TYPE == 1)
		{
		  dist = (dist4[cptsym][EPMIN][rs>>2]>>((rs&3)<<1))&3;

		  if (dist == 0)
		    {
		      dist4[cptsym][EPMIN][rs>>2] |=
			quad_depth<<((rs&3)<<1);
		      count[4]++;
		    }
		}

	      if (DIST4_TYPE == 2)
		{
		  tmp = dist4[cptsym][EPMIN][rs>>1];
	          dist = ((rs&1) ? tmp>>4 : tmp&0xF);

		  if (dist == 0)
		    {
		      dist4[cptsym][EPMIN][rs>>1] |= ((rs&1)?n<<4:n);
		      count[4]++;
		    }
		}
	    }
	}
      else
	{
	  #if USE_CHK_DUP
	  if (n <= 5)
	    if (chk_dup_3c(EPMIN, m.etsym, CPSYM, CTSYM, n))
	      continue;
          #endif

	  seq[n] = mv;
	  search(&m, n+1, seq_gen[mv]);
	}
    }
}

void init()
{
  int i, cnt;
  char fname[DAT_FNAME_LEN];

  if (SHOW_DEFINES || SHOW_METHODS)
    show_settings();

  for (cnt=0, i=1; i <= 4; i++)
      cnt += use_dist[i];

  if (cnt == 0)
    {
      printf("Nothing to do, all USE_DIST's defined to 0\n");
      exit(0);
    }

  for (i=1; i <= 4; i++)
    if (check_gen_depth(i, use_dist, dist_depth))
      exit(0);

  init_dist();

  for (i=1; i <= 4; i++)
      dist_arr[i][0] = 1;

  metric = 'F' ;

  for (cnt=0, i=1; i <= 4; i++)
    if (use_dist[i])
      {
	snprintf(fname, DAT_FNAME_LEN, "dat/D%d_%04d%c_%02d%c.dat",
		i, dist_size[i], dist_type[i], dist_depth[i], metric);

	if (check_dist_file(fname))
	  {
	    printf("Skipping:   %s - file exists\n", fname+4);
	    use_dist[i] = 0;
	    update_use_dist(i);
	    continue;
	  }

	if (dist_depth[i] > max_depth)
	  max_depth = dist_depth[i];

	printf("Generating: %s\n", fname+4);
	cnt++;
      }

  if (cnt == 0)
    {
      printf("\nNothing to do, all files have already been created\n\n");
      exit(0);
    }

  init3();
  seq[0] = NIL;
  report_heading();
}

void show_settings()
{
  printf("Settings:\n");
  if (SHOW_DEFINES)
    show_defines();
  if (SHOW_METHODS)
    show_methods();
  printf("\n");
}

int check_dist_file(fname)
     char *fname;
{
  if ((fp = fopen(fname, "r")) == NULL)
    return(0);
  else
    {
      fclose(fp);
      return(1);
    }
}

void init_dist()
{
  dist_sizeof[1] = sizeof(dist1);
  dist_sizeof[2] = sizeof(dist2);
  dist_sizeof[3] = sizeof(dist3);
  dist_sizeof[4] = sizeof(dist4);

  dist_arr[1] = dist1[0][0];
  dist_arr[2] = dist2[0][0];
  dist_arr[3] = dist3[0][0];
  dist_arr[4] = dist4[0][0];

  dist_type[3] = get_dist_type(DIST3_TYPE);
  dist_type[4] = get_dist_type(DIST4_TYPE);

  use_d1 = USE_DIST1;
  use_d2 = USE_DIST2;
  use_d3 = USE_DIST3;
  use_d4 = USE_DIST4;
}

void report_heading()
{
  int i;

  printf("\n  Moves");

  for (i=1; i <= 4; i++)
    if (use_dist[i])
      printf("           D%d", i);

  printf("\n  -----");

  for (i=1; i <= 4; i++)
    if (use_dist[i])
      printf("  -----------");

  printf("\n");
}

void show_line(mv)
     int mv;
{
  int i;

  printf("%5d  ", mv);

  for (i=1; i <= 4; i++)
    if (use_dist[i])
      printf("  %11ld", count[i]);

  printf("\n");
  fflush(stdout);
}

void update_use_dist(n)
     int n;
{
  switch (n)
    {
    case 1: use_d1 = 0; break;
    case 2: use_d2 = 0; break;
    case 3: use_d3 = 0; break;
    case 4: use_d4 = 0; break;
    };
}

void update_dist(n)
     int n;
{
    if (dist_type[n] == 'H')
      update_hexd(dist_arr[n], dist_sizeof[n]);
    if (dist_type[n] == 'Q')
      update_quad(dist_arr[n], dist_sizeof[n]);
}

void write_dist_file(n)
     long n;
{
  char fname[DAT_FNAME_LEN];

  snprintf(fname, DAT_FNAME_LEN, "dat/D%d_%04d%c_%02d%c.dat",
	   n, dist_size[n], dist_type[n], dist_depth[n], metric);

  printf("Writing %s\n", fname+4);
  fflush(stdout);
  make_bin_file(fname, dist_arr[n], dist_sizeof[n], CHAR);
}

void update_hexd(dist, size)
     unsigned char *dist;
     long size;
{
  int i;

  for (i=0; i < size; i++)
    {
      if ((dist[i]&0xF) == 0)
	dist[i] |= max_depth+1;

      if ((dist[i]>>4) == 0)
	dist[i] |= (max_depth+1)<<4;
    }

  dist[0] &= 0xF0;
}

void update_quad(dist, size)
     unsigned char *dist;
     long size;
{
  // assign 0->3, 3->2, 2->1, 1->0

  long n;
  unsigned char i, j, k, x;
  unsigned char rearrange[256];

  for (i=n=0; n < 256; i++, n++)
    {
      for (j=x=0; j < 4; j++)
	{
	  k = ((i>>((j&3)<<1))&3);

	  if (k == 0)
	    x |= 3<<((j&3)<<1);
	  else if (k == 2)
	    x |= 1<<((j&3)<<1);
	  else if (k == 3)
	    x |= 2<<((j&3)<<1);
	}
      rearrange[i] = x;
    }

  for (n=0; n < size; n++)
    dist[n] = rearrange[dist[n]];
}

void show_defines()
{
  printf("  USE_CHK_DUP      = %d\n", USE_CHK_DUP);
  printf("  SYM_FIRST_MOVE   = %d\n", SYM_FIRST_MOVE);
}
