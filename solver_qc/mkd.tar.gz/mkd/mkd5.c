/* Author: Michael Feather

  Moves    Configs
    1            2
    2            9
    3           76
    4          708
    5         5022
    6        28248
    7       132076
    8       505705
    9      1102421
   10       375380
   11         2360
*/

#include "rc.h"    
#include "func.h"

int bs, cp_bs, ct_bs, brkpt, count, depth, seq[STACK_DEPTH];
unsigned char dist[C_TWIST][MIN_CP6C];
char cp6c_min_op2[MIN_CP6C][CUBE_SYM];
jmp_buf env;

int main()
{
  char fname[DAT_FNAME_LEN];

  init();
  snprintf(fname, DAT_FNAME_LEN, "dat/D5_0001H_11%c.dat", metric);
  printf("Generating: %s\n", fname+4);
  populate_dist_array();
  printf("Writing: %s\n", fname+4);
  make_bin_file(fname, dist, sizeof(dist)/2, CHAR);
  exit(0);
}

void populate_dist_array()
{
  int i;
  struct S_CUBE c;

  brkpt = 6;

  c.cp = c.ct = 0;
  c.cp6c = 0;
  c.cpt.min = c.cpt.op = 0;
  dist[0][0] = 1;
  bs = FALSE;
  printf("  Moves    Configs\n");

  for (depth=1; depth <= brkpt; depth++)
    {
      count = 0;
      search(&c, 1, mvlist2);
      show_dist_count_line(depth, count);
    }

  bs = TRUE;

  for (i=0; i < 4; i++)
    {
      count=0;
      backsearch(1);
      show_dist_count_line(brkpt+1, count);
      brkpt++;
    }

  backsearch(3);
  dist[0][0] = 0;
  show_dist_counts(dist, sizeof(dist), brkpt+1);
  mk_hexd_arr(dist, sizeof(dist));
}

void search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  int i, mv, cpsym, ctsym;
  struct S_CUBE m;
  struct s_cpt *csym;
  struct s_min *cpi;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      CP6C_MOV_CODE;
      CORNER_MOV_CODE;

      cpi = &cp6c_info[m.cp6c];
      m.op = cpi->op;

      CORNER_SYM_CODE;

      if (n == depth)
	{
	  if (bs == FALSE)
	    {
	      if (dist[CTSYM][CP6C_MIN] == 0) 
		{
		  dist[CTSYM][CP6C_MIN] = depth;
		  count++;
		}
	    }
	  else
	    {
	      if (dist[CTSYM][CP6C_MIN] == brkpt)
		{
		  dist[ct_bs][cp_bs] = brkpt+depth;
		  count++;
		  longjmp(env,1);
		}
	    }
	}
      else
	{
	  seq[n] = mv;
	  search(&m, n+1, seq_gen[mv]);
	}
    }
}

void backsearch(n)
     int n;
{
  int i, j, x, cp6c;
  struct S_CUBE c;

  for (i=0; i < MIN_CP6C; i++)
    {
      cp6c = min_cp6c[i];
      cp_bs = i;

      c.cp6c = cp6c;
      c.cp = cp6c_cp3c[cp6c];

      for (j=0; j < C_TWIST; j++)
	{
	  ct_bs = j;
	  c.ct = j;
	  x = c.cp*C_TWIST + c.ct;
	  c.cpt.min = cpt_min[x];
	  c.cpt.op  = inv_op[cpt_min_op[x]];


	  if (dist[ct_bs][cp_bs] == 0)
	    if (setjmp(env) == 0)
	      for (depth=1; depth <= n; depth++)
		{
		  search(&c, 1, mvlist2);
		}
	}
    }
}

void init()
{
  int i, j;

  init3();
  seq[0] = NIL;

  for (i=j=0; i < C_PERM; i++)
    if (cp6c_min_op[i] == 0)
      min_cp6c[j++] = i;
}
