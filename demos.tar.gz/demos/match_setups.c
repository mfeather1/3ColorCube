/* 
Example Usage:
match_setups 4 0 RBRBRYRYRBYBYRYBBBYYYRBRBYBRBBRYBBYBYRYBYBYYYRYRRRRRBR
1 1 2 Z RBRRRRRRRBBBYYYBBBYYYBBRYYYRBBYYYBBBYYYBBBYYYRRRRRRRBR Z
1 2 2 Z RBRRRRRRRBBBYYYBBBYYYRBBYYYRBBYYYBBBYYYBBBYYYRRRRRRRBR Z  B2
1 3 3 Z RBRRRRRRRBBBYYYBBBYYYRBRYYYBBBYYYBBBYYYBBBYYYRRRRRRRBR Z  L2 B2
3 1 1 Y RRRRRRRYRBBBYRYBBBYYYBBBYYYBBBYYYBBBYRYBBBYYYRYRRRRRRR Y'
4 1 1 0 RRRBRRRRRBYBYYYBBBYYYBBBYYBRBBYYYBBBYYYBBBYYYRRRRRRRRR U2
4 1 3 0 RRRBRRRRRBYBYYYBBBYYYRBBYYYBBBYYBBBBYYYBBBYYYRRRRRRRRR Z2
4 2 2 0 RRRBRRRRRBYBYYYBBBYYYBBRBYYBBBYYYBBBYYYBBBYYYRRRRRRRRR Z2 X'

Input Params:
1: # of facelets that must match setup 
2: # of matches to show per sequence, 0 = show all
3: cube configuration

Output:
Column  Description
------  ----------------------------------------------------------------------
   1    Edge Sequence Number
   2    Number of moves to make the setup
   3    Number of visible misplaced facelets on UFR faces (subtracted from 4)
   4    Rotation of cube from setups.db 
   5    Cube showing just the facelets in the setup
   6    Moves to make the setup
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HOME "UUUUUUUUULLLFFFLLLFFFLLLFFFLLLFFFLLLFFFLLLFFFUUUUUUUUU"
#define DB "setups.db"

int IX, FIX, MAX;
char CUBE[55], UNCOLOR[55];
char U, L, F;
FILE *fp;
char LINE[100];
char arr[100][100];
int cmp();
char *color();

int eix[54]=
{  0,19, 0,10, 0,16, 0,13, 0, 0, 3, 0, 0, 7, 0, 0, 5, 0,
   0, 1, 0,32, 0,24,23, 0,27,26, 0,30,29, 0,21, 0,48, 0,
   0,46, 0, 0,50, 0, 0,52, 0, 0,37, 0,34, 0,40, 0,43, 0
};

main(argc, argv)
  int argc;
  char **argv;
{
  int i;

  // for (i=0; i < 54; i++) if (eix[i] != 0) printf("%2d %2d\n", i, eix[i]);  exit(0);

  if (argc != 4)
  {
    printf("Usage: \n");
    printf("%s {fix#} {max (0=all)} {cube string}\n", argv[0]);
    exit(0);
  }

  open_file(DB, "r");

  FIX=atoi(argv[1]);
  MAX=atoi(argv[2]);
  strcpy(CUBE, argv[3]);

  // printf("FIX=%d\n", FIX);
  // printf("MAX=%d\n", MAX);
  // printf("CUBE=%.54s\n", CUBE);

  U=CUBE[4];  L=CUBE[22];  F=CUBE[25];

  for (i=0; i < 54; i++)
  {
    if (CUBE[i] == U) UNCOLOR[i] = 'U';
    if (CUBE[i] == L) UNCOLOR[i] = 'L';
    if (CUBE[i] == F) UNCOLOR[i] = 'F';
  }
  // printf("UNCOLOR=%s\n", UNCOLOR);

  if (strncmp(UNCOLOR, HOME, 54) == 0)
  {
    printf("Cube is Already Solved!\n");
    exit(0);
  }

  if (FIX == 4)
  {
    e1_fix4(); sort(); head(MAX);
    e3_fix4(); sort(); head(MAX);
    e4_fix4(); sort(); head(MAX);
  }

  if (FIX == 3)
  {
    e1_fix3(); sort(); head(MAX);
    e3_fix3(); sort(); head(MAX);
    e4_fix3(); sort(); head(MAX);
  }

  if (FIX == 2)
  {
    e1_fix2(); sort(); head(MAX);
    e2_fix2(); sort(); head(MAX);
    e3_fix2(); sort(); head(MAX);
    e4_fix2(); sort(); head(MAX);
    e4_fix2b(); sort(); head(MAX);   // one cubie matches setup
  }

  if (FIX == 1)
  {
    // e1_fix1(); sort(); head(MAX);
    e2_fix1(); sort(); head(MAX);
  }

  if (FIX == 0)
  {
    e0_fix0(); sort(); head(MAX);
  }

  exit(0);
}

e1_fix4()
{
  while (fgets(LINE, 100, fp) != NULL)
    if (LINE[0] == '1')
      ff(&LINE[4]);
  rewind(fp);
}

e3_fix4()
{
  while (fgets(LINE, 100, fp) != NULL)
    if (LINE[0] == '3')
      ff(&LINE[4]);
  rewind(fp);
}

e4_fix4()
{
  while (fgets(LINE, 100, fp) != NULL)
    if (LINE[0] == '4')
      ff(&LINE[4]);
  rewind(fp);
}

e1_fix3()
{
  gg("1 0", 'L');
  gg("1 Y", 'U');
  gg("1 Z", 'F');
}

e3_fix3()
{
  gg("3 0", 'U');
  gg("3 X", 'F');
  gg("3 Y", 'L');
}

e4_fix3()
{
  jjn("4 0", "FUUF", 4);    // replace F with U then replace U with F
  jjn("4 Y", "LFFL", 4);
  jjn("4 Z", "LUUL", 4);
}

e1_fix2()
{
  // 2 misplaced on opposite faces, other 2 flipped 
  jjn("1 0", "FLUL", 4);    // replace F with L then replace U with L
  jjn("1 Y", "FULU", 4);
  jjn("1 Z", "LFUF", 4);
  /* 
   3 misplaced, 1 correct
   this shows duplicate cubes when there are two correct facelets opposite a 
   misplaced one (within the slice), either can be used to match the setup but
   the cube looks the same in both cases.  To eliminate the duplicates just do
   sort -u on the facelets in the result set.
  */
  // hh("1 0", 'U', 'F');
  // hh("1 Y", 'F', 'L');
  // hh("1 Z", 'L', 'U');
}

e2_fix2()
{
  while (fgets(LINE, 100, fp) != NULL)
    if (LINE[0] == '2')
      ff(&LINE[4]);
  rewind(fp);
}

e3_fix2()
{
  jjn("3 0", "FULU", 4);    // replace F with U then replace L with U
  jjn("3 X", "LFUF", 4);
  jjn("3 Y", "FLUL", 4);
}

e4_fix2()
{
  mm("4 0", "FU");      // swap F & U
  mm("4 Y", "LF");
  mm("4 Z", "LU");
}

e4_fix2b()
{
  char i, z0, z1, s[4], u[4], v[4], x[4], setup_cube[54], mv_list[30];
  while (fgets(LINE, 100, fp) != NULL)
  {
    if (LINE[0] == '4')
    {
      strncpy(s, &LINE[4], 4);
      sscanf(&LINE[9], "%d %d %d %d\n", &x[0], &x[1], &x[2], &x[3]);
      for (i=0; i < 4; i++) 
        u[i] = UNCOLOR[x[i]];
      // get indexes of two facelets that are same color on setup cube
      zz(s, v);
      z0 = yy(x, eix[x[v[0]]]);  // get index of other facelet on same cubie
      z1 = yy(x, eix[x[v[1]]]);
      // if two misplaced facelets on right face are same color
      if (u[v[2]] == u[v[3]])
      // and both facelets on one of the cubies match the setup
      if ((s[v[0]] == u[v[0]] && s[z0] == u[z0]) ||  
          (s[v[1]] == u[v[1]] && s[z1] == u[z1]))
      {
        mk_setup_cube(setup_cube, &LINE[4], x[0], x[1], x[2], x[3]);
        if (strlen(LINE) < 27) strcat(LINE, "\n");
        // sprintf(arr[IX++], "%c %c %c %c %.54s %s", LINE[0], LINE[2], 
        // LINE[24], LINE[22], setup_cube, &LINE[26]);
        sprintf(arr[IX++], "%c %c %d %c %.54s %s", LINE[0], LINE[24], 
        52-LINE[22], LINE[2], setup_cube, &LINE[26]);
      }
    }
  }
  rewind(fp);
}

yy(arr, n)
char *arr, n;
{
  int i;
  for (i=0; i < 4; i++)
    if (arr[i] == n)
      return(i);
}

zz(s, v)
  char *s, *v;
{
  if (s[0] == s[1]) {v[0]=0; v[1]=1; v[2]=2; v[3]=3;}
  if (s[0] == s[2]) {v[0]=0; v[1]=2; v[2]=1; v[3]=3;}
  if (s[0] == s[3]) {v[0]=0; v[1]=3; v[2]=1; v[3]=2;}
  if (s[1] == s[2]) {v[0]=1; v[1]=2; v[2]=0; v[3]=3;}
  if (s[1] == s[3]) {v[0]=1; v[1]=3; v[2]=0; v[3]=2;}
  if (s[2] == s[3]) {v[0]=2; v[1]=3; v[2]=0; v[3]=1;}
}

/* no longer used
e1_fix1()
{
  int x0, x1, x2, x3;
  char setup_cube[54];
  // only use this for configs where there are six misplaced facelets
  // where one is fixable (ccs cube) 
  if (ct_mp(UNCOLOR) != 6 || cc(UNCOLOR)) 
     return;
  fclose(fp);
  open_file("setups_3CE1_alt.db", "r");
  while (fgets(LINE, 100, fp) != NULL)
  {
    sscanf(&LINE[5], "%d %d %d %d\n", &x0, &x1, &x2, &x3);
    if (UNCOLOR[x0] == LINE[0] && UNCOLOR[x1] == LINE[1] &&
        UNCOLOR[x2] == LINE[2] && UNCOLOR[x3] == LINE[3]) 
    {
       mk_setup_cube(setup_cube, LINE, x0, x1, x2, x3);
       sprintf(arr[IX++], "1 %d 0 0 %.54s %s", 
         count_tokens(&LINE[17]), setup_cube, &LINE[17]);
    }
  }
  fclose(fp);
  open_file(DB, "r");
}
*/

ct_mp(s)       // count misplaced facelets
  char *s;
{
  int i, c;
  for (i=c=0; i < 54; i++) if (s[i] != HOME[i]) c++;
  return(c);
}

cc(s)        // return 1 if none fixable
  char *s;
{
  int i, j, ct[7], ct2=0; 
  int grp[54] = 
  { 0,1,0,2,0,2,0,1,0,0,3,0,0,5,0,0,3,0,0,5,0,4,0,4,6,0,6,
    4,0,4,6,0,6,0,3,0,0,5,0,0,3,0,0,5,0,0,1,0,2,0,2,0,1,0 };
  for (i=1; i <= 6; i++) ct[i] = 0;
  for (i=0; i < 54; i++) if (s[i] != HOME[i]) ct[grp[i]]++;
  for (i=1; i <= 6; i++) if (ct[i] == 2) ct2++;
  if (ct2 == 3)
    return(1);
  return(0);
}

e2_fix1()
{
  jjn("2 0", "FLUL", 2);    // replace F with L then replace U with L  
  jjn("2 Y", "LUFU", 2);
  jjn("2 Z", "UFLF", 2);
}

e0_fix0()
{
  int x0, x1, x2, x3;
  char setup_cube[54];
  fclose(fp);
  open_file("setups_3CE1_alt.db", "r");
  while (fgets(LINE, 100, fp) != NULL)
  {
    sscanf(&LINE[5], "%d %d %d %d\n", &x0, &x1, &x2, &x3);
    if (UNCOLOR[x0] == LINE[0] &&
        UNCOLOR[x1] == LINE[1] &&
        UNCOLOR[x2] == LINE[2] &&
        UNCOLOR[x3] == LINE[3]) 
    {
       mk_setup_cube(setup_cube, LINE, x0, x1, x2, x3);
       sprintf(arr[IX++], "1 %d 0 0 %.54s %s", 
         count_tokens(&LINE[17]), setup_cube, &LINE[17]);
    }
  }
  fclose(fp);
  open_file(DB, "r");
}

gg(s, c)           // makes: csss scss sscs sssc
  char *s, c;
{
  int i;
  char v[4], vv[4];
  while (fgets(LINE, 100, fp) != NULL)
    if (strncmp(LINE, s, 3) == 0) 
    {
      sprintf(v, "%.4s", &LINE[4]);
      for (i=0; i < 4; i++)
      {
        strncpy(vv, v, 4);
        vv[i] = c;
        ff(vv);
      } 
    }
  rewind(fp);
}

hh(s, c1, c2)      // switches c1 & c2 in position vv[i] (four switches)
  char *s, c1, c2;
{
  int i;
  char c, v[4], vv[4];
  while (fgets(LINE, 100, fp) != NULL)
    if (strncmp(LINE, s, 3) == 0) 
    {
      sprintf(v, "%.4s", &LINE[4]);
      for (i=0; i < 4; i++)
      {
        strncpy(vv, v, 4);
        vv[i] = (v[i]==c1) ? c2 : c1;
        ff(vv);
      } 
    }
  rewind(fp);
}

jjn(s, a, n)       // replace all c0 with c1, c2 with c3, c0=a[0]...
  char *s, *a;
  int n;
{
  int i;
  char v[4], vv[4];
  while (fgets(LINE, 100, fp) != NULL)
    if (strncmp(LINE, s, 3) == 0) 
    {
      sprintf(v, "%.4s", &LINE[4]);
      strncpy(vv, v, 4);
      for (i=0; i < n; i++) 
        if (vv[i] == a[0]) 
          vv[i] = a[1];  
      ff(vv);
      strncpy(vv, v, 4);
      for (i=0; i < n; i++) 
        if (vv[i] == a[2]) 
          vv[i] = a[3];  
      ff(vv);
    }
  rewind(fp);
}

mm(s, a)           // swap a[0] & a[1]
  char *s, *a;
{
  int i;
  char v[4], vv[4];
  while (fgets(LINE, 100, fp) != NULL)
    if (strncmp(LINE, s, 3) == 0) 
    {
      sprintf(v, "%.4s", &LINE[4]);
      // strncpy(vv, v, 4);
      for (i=0; i < 4; i++)
      { 
        if (v[i] == a[0]) 
          v[i] = a[1];  
        else if (v[i] == a[1]) 
          v[i] = a[0];  
      }
      ff(v);
    }
  rewind(fp);
}

ff(s)
 char *s;
{
  char setup_cube[54], mv_list[30];
  int x0, x1, x2, x3;
  sscanf(&LINE[9], "%d %d %d %d\n", &x0, &x1, &x2, &x3);
  if (UNCOLOR[x0] == s[0] && UNCOLOR[x1] == s[1] &&
      UNCOLOR[x2] == s[2] && UNCOLOR[x3] == s[3]) 
  {
    mk_setup_cube(setup_cube, s, x0, x1, x2, x3);
    //if (LINE[26] == 0) { LINE[26] = '\n'; LINE[27] = '\0'; }
    if (strlen(LINE) < 27) strcat(LINE, "\n");
    //    sprintf(arr[IX++], "%c %c %c %c %.54s %s", LINE[0], LINE[2], 
    //      LINE[24], LINE[22], setup_cube, &LINE[26]);
    sprintf(arr[IX++], "%c %c %d %c %.54s %s", LINE[0], LINE[24], 
      52-LINE[22], LINE[2], setup_cube, &LINE[26]);
    // if change sprintf also change in e4_fix2b(), e1_fix1() & e0_fix0()
  }
}

mk_setup_cube(s, ss, x0, x1, x2, x3)
  char *s, *ss;
  int x0, x1, x2, x3;
{
  int i;
  for (i=0; i < 54; i++)
    s[i] = chr(HOME[i]);
  s[x0] = chr(ss[0]);
  s[x1] = chr(ss[1]);
  s[x2] = chr(ss[2]);
  s[x3] = chr(ss[3]);
}

chr(c)
char c;
{
  if (c == 'U') return(U);
  if (c == 'L') return(L);
  if (c == 'F') return(F);
}

open_file(fname, mode)
     char *fname, *mode;
{
  if ((fp = fopen(fname,mode)) == NULL)
    {
      printf("Error opening file: <%s>\n", fname);
      exit(1);
    }
}

sort()
{
  qsort(arr, IX, 100, cmp);
}

head(n)
  int n;
{
  int i;
  if (IX==0) return;
  if (n==0 || n > IX) n = IX;
  for (i=0; i < n; i++)
    printf("%s", arr[i]);
  IX=0;
}

cmp(a, b)
  char *a, *b;
{
  return(strcmp(a, b));
}

instr(s, c)
char *s, c;
{
  int i;
  for (i=0; i < strlen(s); i++)
     if (s[i] == c)
      return(i);
  return(0);
}

count_tokens(s)
char *s;
{
  int n=0;
  char *p = s;
  for (;;)
  {
    while (*p == ' ') p++;
    if (*p == 0) break;
    if (*p != '\n') n++;
    while (*p != 0 && *p != ' ')
      p++;
  }
  return n;
}

char *
color(s)
  char *s;
{
  int i;
  for (i=0; i < 54; i++)
  {
    if (s[i] == 'U') s[i] = U;
    if (s[i] == 'L') s[i] = L;
    if (s[i] == 'F') s[i] = F;
  }
  return(s);
}
