// Author: Michael Feather 

#include <stdio.h>
#include <stdlib.h>
#include <sys/timeb.h>

#include "rc.h"

#define RANDOM_SEED      1   /* 0 = generate same list each run */
#define CUBE_FORMAT      1   /* 1=single line, 0=cube display (9 lines)   */
#define CORNERS_SOLVED   0

#define C_UP     'R'
#define C_LEFT   'G'
#define C_FRONT  'Y'
#define C_RIGHT  'B'
#define C_BACK   'W'
#define C_DOWN   'O'

main(argc, argv)
     int argc;
     char **argv;
{
  int i, cp, ct, ep, et, count;
  struct s_cube cube;
  char cubestr[FACELETS];
  struct timeb ft;

  if (argc == 1) 
    {
      printf("Usage: %s {#cubes}\n", argv[0]); 
      exit(0);
    }

  init(cubestr);

  if (RANDOM_SEED){
    ftime(&ft);
    srandom(ft.time*1000 + ft.millitm);
  }

  for (i=count=0; count < atoi(argv[1]); i++)
    {
      if (CORNERS_SOLVED) {
        cp = 0;
        ct = 0;
      }
      else {
        cp = random() % C_PERM;
        ct = random() % C_TWIST;
      }

      ep = random() % (E_PRM*E_PRMr);
      et = random() % E_TWIST;

      int_to_perm(cp, cube.cps, 8);
      int_to_perm(ep, cube.eps, 12);
      int_to_strp(ct, cube.cts, 7, 3);
      int_to_strp(et, cube.ets, 11, 2);

      if (parity(cube.eps, 12) != parity(cube.cps, 8))
	continue;

      make_cubestr(cubestr, &cube);
      show_cubestr(cubestr, CUBE_FORMAT);
      count++;
    }
}

init(cubestr)
     char *cubestr;
{
  untwc[1] = 2;
  untwc[2] = 1;
  init_conv();

  cubestr[4]  = C_UP; 
  cubestr[22] = C_LEFT; 
  cubestr[25] = C_FRONT; 
  cubestr[28] = C_RIGHT; 
  cubestr[31] = C_BACK; 
  cubestr[49] = C_DOWN; 
  set_colors_6c(C_RIGHT, C_FRONT, C_UP, C_LEFT, C_BACK, C_DOWN);
}
